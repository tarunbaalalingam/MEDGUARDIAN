@echo off
REM sync_schedule.bat — Edit the Med Guardian schedule with auto-sync to Pico
REM Usage: Double-click this file
REM
REM 1. Opens med_guardian.txt in Notepad (stays open)
REM 2. Starts background watcher that syncs saved changes every 5 seconds
REM 3. Press any key to stop watching and close this window

set FIRMWARE_DIR=%~dp0
cd /d "%FIRMWARE_DIR%"

echo.
echo ========================================
echo   Med Guardian — Schedule Auto-Sync
echo ========================================
echo.
echo Opening schedule file in Notepad...
echo Keep Notepad open. Your saved changes will sync to Pico every 5 seconds.
echo.
echo Press any key in THIS window to stop auto-syncing.
echo.

REM Open Notepad (does not block)
start notepad "%FIRMWARE_DIR%med_guardian.txt"

REM Start the background file watcher and sync loop
powershell -ExecutionPolicy Bypass -NoExit -Command "
$dir = '%FIRMWARE_DIR%'
Set-Location $dir
$txtFile = 'med_guardian.txt'
$lastHash = $null
Write-Host 'Watching for changes to med_guardian.txt...' -ForegroundColor Yellow
Write-Host 'Syncs to Pico automatically when you save in Notepad.' -ForegroundColor Yellow
Write-Host 'Press Ctrl+C to stop watching.' -ForegroundColor Yellow
Write-Host ''
while ($true) {
    if (Test-Path $txtFile) {
        $content = Get-Content $txtFile -Raw
        $currentHash = [System.HashAlgorithm]::MD5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($content))
        if ($lastHash -ne $currentHash) {
            Write-Host \"[$(Get-Date -Format 'HH:mm:ss')] Change detected, syncing...\" -ForegroundColor Cyan
            & powershell -ExecutionPolicy Bypass -File 'sync_schedule.ps1' 2>&1
            $lastHash = $currentHash
        }
    }
    Start-Sleep -Seconds 5
}
"

pause
