from machine import Pin,time_pulse_us
import time
class HCSR04:
    def __init__(self,trig,echo): self.trig=Pin(trig,Pin.OUT,value=0); self.echo=Pin(echo,Pin.IN)
    def distance(self):
        self.trig.off(); time.sleep_us(2); self.trig.on(); time.sleep_us(10); self.trig.off()
        pulse=time_pulse_us(self.echo,1,25000)
        if pulse<0: raise OSError('Ultrasonic timeout')
        return pulse/58.0
