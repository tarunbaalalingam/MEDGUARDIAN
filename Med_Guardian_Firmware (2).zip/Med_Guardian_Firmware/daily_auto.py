"""Printed schedule reminders from med_guardian.txt. No motion, no buzzer."""
import time
import uasyncio as asyncio

SETTINGS_FILE = 'med_guardian.txt'
SLOTS = ('MORNING', 'AFTERNOON', 'NIGHT')


def read_settings():
    settings = {}
    with open(SETTINGS_FILE) as handle:
        for raw in handle:
            line = raw.strip()
            if not line or line.startswith('#'):
                continue
            if '=' not in line:
                raise ValueError('Invalid settings line')
            key, value = line.split('=', 1)
            key = key.strip()
            value = value.strip()
            if key in settings:
                raise ValueError('Duplicate setting: ' + key)
            settings[key] = value
    for slot in SLOTS:
        value = settings.get(slot, '')
        if (len(value) != 5 or value[2] != ':' or
                not value[:2].isdigit() or not value[3:].isdigit()):
            raise ValueError('Invalid time: ' + slot)
        if int(value[:2]) > 23 or int(value[3:]) > 59:
            raise ValueError('Invalid time: ' + slot)
    if settings.get('REFILL_MODE', 'false').lower() not in ('true', 'false'):
        raise ValueError('Invalid REFILL_MODE')
    return settings


async def run_daily(clock, timezone_minutes):
    print('Standalone reminders: %s; printed only, no buzzer.' % SETTINGS_FILE)
    settings = None
    last_check = time.ticks_ms()
    last_key = None
    last_error = None
    trusted = False
    while True:
        try:
            if time.ticks_diff(time.ticks_ms(), last_check) >= 5000:
                last_check = time.ticks_ms()
                try:
                    settings = read_settings()
                    last_error = None
                except Exception as exc:
                    settings = None
                    if str(exc) != last_error:
                        last_error = str(exc)
                        print('Schedule file unavailable:', type(exc).__name__)

            if settings is None:
                trusted = False
            elif clock.trusted():
                if not trusted:
                    trusted = True
                    print('Reminders active; clock is trusted.')
                now = clock.now()
                local = time.gmtime(now + timezone_minutes * 60)
                current = '%02d:%02d' % (local[3], local[4])
                key = '%04d-%02d-%02d %s' % (local[0], local[1], local[2], current)
                if key != last_key:
                    last_key = key
                    for slot in SLOTS:
                        if settings[slot] == current:
                            print('REMINDER:', slot, 'scheduled', current, '- printed only')
            elif trusted:
                trusted = False
                print('Reminders suspended: clock is not trusted.')

        except Exception as exc:
            print('Reminder monitor error:', type(exc).__name__)

        await asyncio.sleep(1)
