# sync_schedule.ps1 — convert med_guardian.txt to schedule.json and upload to Pico
# Run from: C:\Users\admin\Downloads\Med_Guardian_Firmware
# Usage: .\sync_schedule.ps1

$ErrorActionPreference = "Stop"
$COM = "COM5"
$txtFile = "med_guardian.txt"
$jsonFile = "schedule.json"

# Parse med_guardian.txt
$settings = @{}
Get-Content $txtFile | ForEach-Object {
    $line = $_.Trim()
    if ($line -and $line -notlike '#*') {
        if ($line -match '=') {
            $key, $value = $line -split '=', 2
            $settings[$key.Trim()] = $value.Trim()
        }
    }
}

# Build schedule.json content
$schedule = @{
    morning = $settings['MORNING']
    afternoon = $settings['AFTERNOON']
    night = $settings['NIGHT']
}

# Convert to JSON (null for empty, string for time)
$jsonObj = @{
    morning = if ($schedule.morning) { $schedule.morning } else { $null }
    afternoon = if ($schedule.afternoon) { $schedule.afternoon } else { $null }
    night = if ($schedule.night) { $schedule.night } else { $null }
}

$jsonContent = $jsonObj | ConvertTo-Json -Compress
Set-Content -Path $jsonFile -Value $jsonContent -NoNewline

Write-Host "Parsed schedule from ${txtFile}:" -ForegroundColor Cyan
Write-Host "  MORNING:   $($schedule.morning)"
Write-Host "  AFTERNOON: $($schedule.afternoon)"
Write-Host "  NIGHT:     $($schedule.night)"
Write-Host ""
Write-Host "Generated ${jsonFile}: ${jsonContent}" -ForegroundColor Green
Write-Host ""

# Upload both files to Pico
Write-Host "Uploading ${txtFile} to Pico ..." -ForegroundColor Cyan
try {
    py -3 -m mpremote connect $COM fs cp $txtFile ":$txtFile" 2>&1 | Out-Null
    Write-Host "  OK" -ForegroundColor Green
} catch {
    Write-Host "  FAILED: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host "Uploading ${jsonFile} to Pico ..." -ForegroundColor Cyan
try {
    py -3 -m mpremote connect $COM fs cp $jsonFile ":$jsonFile" 2>&1 | Out-Null
    Write-Host "  OK" -ForegroundColor Green
} catch {
    Write-Host "  FAILED: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "Schedule synced! The Pico will pick up the new times within 5 seconds." -ForegroundColor Green
Write-Host "No restart needed. daily_auto.py re-reads the file every 5 seconds." -ForegroundColor Green
