from machine import Pin
import uasyncio as asyncio
class Buzzer:
    """Digital active buzzer on GP14; no PWM peripheral is used."""
    def __init__(self,pin): self.pin=Pin(pin,Pin.OUT,value=0)
    async def chirp(self):
        self.pin.on()
        try: await asyncio.sleep_ms(80)
        finally: self.pin.off()

    def close(self): self.pin.off()
