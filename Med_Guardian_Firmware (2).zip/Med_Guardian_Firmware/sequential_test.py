# Med Guardian - slow sequential commissioning test.
# Runs ON THE PICO beside the firmware modules.
# Read-only by default: no PWM, no HC-SR04 pulse, no dispensing.
# Motion requires the exact supervised confirmation string below.

import time
import config
import pins
from configuration import validate
from safety_manager import finite, interlocks, preflight

SLOTS = ('MORNING', 'AFTERNOON', 'NIGHT')
SEQUENCE_SLOTS = ('morning', 'afternoon', 'night')
SUPERVISED_TOKEN = 'EMPTY-COMPARTMENTS-AREA-CLEAR'
GPS_READ_MS = 8000
LIMIT_SETTLE_MS = 350
STEP_PAUSE_MS = 300
MOVE_DWELL_MS = 1500

RESULTS = []
BLOCKERS = []


def add(status, name, detail=''):
    RESULTS.append((status, name, detail))
    if status in ('FAIL', 'BLOCKED'):
        BLOCKERS.append(name + (': ' + str(detail) if detail else ''))
    line = '[%s] %s' % (status, name)
    if detail:
        line += ' - ' + str(detail)
    print(line)


def attr(name, default=None):
    return getattr(config, name, default)


def hhmm(value):
    if (not isinstance(value, str) or len(value) != 5 or value[2] != ':' or
            not value[:2].isdigit() or not value[3:].isdigit()):
        return False
    return int(value[:2]) <= 23 and int(value[3:]) <= 59


def read_settings():
    values = {}
    with open('med_guardian.txt') as handle:
        for raw in handle:
            line = raw.strip()
            if not line or line.startswith('#'):
                continue
            if '=' not in line:
                raise ValueError('Invalid line')
            key, value = line.split('=', 1)
            key = key.strip()
            value = value.strip()
            if key in values:
                raise ValueError('Duplicate ' + key)
            values[key] = value
    if set(values) != set(SLOTS) | {'REFILL_MODE'}:
        raise ValueError('Expected three slots and REFILL_MODE')
    for slot in SLOTS:
        if not hhmm(values[slot]):
            raise ValueError('Invalid time ' + slot)
    if values['REFILL_MODE'].lower() not in ('true', 'false'):
        raise ValueError('Invalid REFILL_MODE')
    return values


def stage_imports():
    print('\n-- Stage 1: configuration and firmware imports --')
    try:
        validate(config)
        add('PASS', 'Configuration validation')
    except Exception as exc:
        add('FAIL', 'Configuration validation', type(exc).__name__ + ': ' + str(exc))
        return False
    required = ('WIRING_VERIFIED', 'ACTUATION_VERIFIED', 'CALIBRATED',
                'USB_TIME_SYNC_ENABLED', 'HC_SR04_ECHO_3V3_SAFE',
                'SERVOS', 'STORAGE_ANGLES', 'SERVO_SEQUENCES')
    missing = [name for name in required if not hasattr(config, name)]
    if missing:
        add('FAIL', 'Required configuration fields', ','.join(missing))
        return False
    names = ('pins', 'configuration', 'safety_manager', 'scheduler', 'clock',
             'limit_switch', 'hx711', 'hcsr04', 'mpu6050', 'gps', 'buzzer',
             'servo_controller', 'sensors', 'dispenser', 'event_logger',
             'protocol', 'communications', 'wifi_manager', 'daily_auto',
             'usb_clock')
    failed = []
    for name in names:
        try:
            __import__(name)
        except Exception as exc:
            failed.append(name + ':' + type(exc).__name__)
    if failed:
        add('FAIL', 'Firmware module imports', ','.join(failed))
        return False
    add('PASS', 'Firmware module imports', '%d modules' % len(names))
    add('INFO', 'Commissioning flags', 'wiring=%s calibration=%s actuation=%s' % (
        config.WIRING_VERIFIED, config.CALIBRATED, config.ACTUATION_VERIFIED))
    add('INFO', 'Buzzer', 'disabled; GP14 is not connected' if not config.BUZZER_ENABLED
        else 'enabled in config; physical function not tested here')
    if not config.WIRING_VERIFIED:
        add('BLOCKED', 'Wiring gate', 'WIRING_VERIFIED is False; no GPIO will be touched')
        return False
    return True


def stage_pins():
    print('\n-- Stage 2: GPIO map and conflicts --')
    try:
        pins.validate()
        add('PASS', 'GPIO conflict check')
    except Exception as exc:
        add('FAIL', 'GPIO conflict check', type(exc).__name__ + ': ' + str(exc))
        return False
    expected = (
        ('ESP_TX', 0), ('ESP_RX', 1), ('HX_DATA', 2), ('HX_CLOCK', 3),
        ('ULTRA_TRIG', 4), ('ULTRA_ECHO', 5), ('MPU_SDA', 6), ('MPU_SCL', 7),
        ('GPS_UART_TX', 8), ('GPS_UART_RX', 9), ('BUZZER', 14),
        ('LIMIT_SWITCH', 16), ('SERVO_1', 18), ('SERVO_2', 19),
        ('SERVO_3', 20), ('SERVO_4', 21),
    )
    mismatch = []
    for name, gpio in expected:
        if getattr(pins, name, None) != gpio:
            mismatch.append('%s!=GP%d' % (name, gpio))
    if mismatch:
        add('FAIL', 'Authoritative pin map', ','.join(mismatch))
        return False
    add('PASS', 'Authoritative pin map', 'ESP GP0/1, HX GP2/3, US GP4/5, '
        'MPU SDA GP6/SCL GP7, GPS TX GP8/RX GP9, buzzer GP14, limit GP16, '
        'servos GP18-GP21')
    add('INFO', 'GPS direction', 'Pico GP8 TX -> GPS RX; GPS TX -> Pico GP9 RX')
    add('INFO', 'MPU orientation', 'SDA GP6, SCL GP7 (I2C1)')
    for pair in ((1, 2), (3, 4)):
        a = config.SERVOS[pair[0]]['frequency']
        b = config.SERVOS[pair[1]]['frequency']
        if a != b:
            add('FAIL', 'Shared PWM slice %d/%d' % pair, 'frequencies %s != %s' % (a, b))
            return False
    add('PASS', 'Shared PWM frequencies', '18/19 and 20/21 pairs match')
    return True


def stage_schedule():
    print('\n-- Stage 3: schedule file --')
    try:
        values = read_settings()
        add('PASS', 'med_guardian.txt', 'MORNING=%s AFTERNOON=%s NIGHT=%s REFILL=%s' % (
            values['MORNING'], values['AFTERNOON'], values['NIGHT'],
            values['REFILL_MODE'].lower()))
    except Exception as exc:
        add('FAIL', 'med_guardian.txt', type(exc).__name__ + ': ' + str(exc))
        return False
    try:
        import json
        from protocol import schedule as validate_schedule
        with open('schedule.json') as handle:
            cached = validate_schedule(json.load(handle))
        add('PASS', 'Cached schedule.json', str(cached))
    except OSError:
        add('INFO', 'Cached schedule.json', 'absent; standalone file is authoritative')
    except Exception as exc:
        add('FAIL', 'Cached schedule.json', type(exc).__name__)
    return True


def stage_limit(interactive):
    print('\n-- Stage 4: limit switch and interlocks --')
    from limit_switch import LimitSwitch
    try:
        switch = LimitSwitch(pins.LIMIT_SWITCH, config.LIMIT_SWITCH_ACTIVE,
                             config.LIMIT_DEBOUNCE_MS)
    except Exception as exc:
        add('FAIL', 'Limit switch initialization', type(exc).__name__)
        return None, False
    time.sleep_ms(LIMIT_SETTLE_MS)
    state = switch.state()
    if not state['ready']:
        add('FAIL', 'Limit switch settle', 'debounced state unavailable')
        return switch, False
    add('PASS', 'Limit switch read', 'raw=%s active=%s docked=%s' % (
        state['raw'], state['active'], state['active']))
    if config.LIMIT_SWITCH_ROLE == 'docked' and config.DOCK_SENSOR_REQUIRED:
        add('PASS', 'Dock switch configured', 'active LOW means docked')
    else:
        add('BLOCKED', 'Dock switch role', 'role=%s required=%s' % (
            config.LIMIT_SWITCH_ROLE, config.DOCK_SENSOR_REQUIRED))
    if config.LID_INTERLOCK_REQUIRED:
        if config.LIMIT_SWITCH_ROLE == 'lid_closed':
            add('PASS', 'Lid interlock input', 'shares the limit switch')
        else:
            add('BLOCKED', 'Lid interlock input',
                'LID_INTERLOCK_REQUIRED=True but LIMIT_SWITCH_ROLE=%s; '
                'no lid sensor is wired. Dispensing cannot pass preflight.' %
                config.LIMIT_SWITCH_ROLE)
    else:
        add('INFO', 'Lid interlock', 'not required by config')
    sample = dict(faults=[], cup_present=True, lid_closed=None,
                  docked=state['active'], tilt_deg=0.0, motion_g=0.0)
    reason = interlocks(config, sample)
    add('INFO', 'Interlock evaluation', reason or 'no static reason reported')
    if state['active']:
        add('BLOCKED', 'Actuator environment', 'unit is docked; undock before movement')
        environment = False
    else:
        add('PASS', 'Actuator environment', 'unit is undocked')
        environment = True
    if interactive:
        try:
            answer = input('Toggle the dock switch within 15 s? Type YES: ').strip().upper()
        except EOFError:
            answer = ''
        if answer == 'YES':
            before = state['sequence']
            deadline = time.ticks_add(time.ticks_ms(), 15000)
            changed = False
            while time.ticks_diff(deadline, time.ticks_ms()) > 0:
                if switch.state()['sequence'] != before:
                    changed = True
                    break
                time.sleep_ms(50)
            if changed:
                add('PASS', 'Limit switch edge', 'operator toggle observed')
            else:
                add('FAIL', 'Limit switch edge', 'no debounced edge within 15 s')
                environment = False
        else:
            add('BLOCKED', 'Limit switch edge', 'physical toggle not performed')
    else:
        add('BLOCKED', 'Limit switch edge', 'physical toggle not performed in read-only run')
    return switch, environment


def stage_mpu():
    print('\n-- Stage 5: MPU6050 --')
    if not config.MPU6050_ENABLED:
        add('SKIP', 'MPU6050', 'disabled in config')
        return None
    try:
        from machine import I2C, Pin
        from mpu6050 import MPU6050
        bus = I2C(1, sda=Pin(pins.MPU_SDA), scl=Pin(pins.MPU_SCL), freq=100000)
        found = bus.scan()
        add('INFO', 'I2C scan', '0x68' if 0x68 in found else ('0x69' if 0x69 in found else str(found)))
        mpu = None
        last = None
        for address in (0x68, 0x69):
            try:
                baseline = None
                bx = getattr(config, 'MPU_BASELINE_X', None)
                by = getattr(config, 'MPU_BASELINE_Y', None)
                bz = getattr(config, 'MPU_BASELINE_Z', None)
                if bx is not None and by is not None and bz is not None:
                    baseline = (bx, by, bz)
                mpu = MPU6050(bus, address, baseline=baseline)
                add('PASS', 'MPU6050 identity', 'address 0x%02X' % address)
                if baseline:
                    add('INFO', 'MPU6050 baseline', 'X=%.3f Y=%.3f Z=%.3f' % (bx, by, bz))
                break
            except Exception as exc:
                last = exc
        if mpu is None:
            raise last or OSError('No MPU6050 response')
        tilt, motion, accel = mpu.read()
        if not finite(tilt) or not finite(motion):
            raise ValueError('Non-finite MPU reading')
        if baseline:
            add('PASS', 'MPU6050 read', 'tilt_deviation=%.2f deg motion=%.3f g accel=%s' % (
                tilt, motion, accel))
        else:
            add('PASS', 'MPU6050 read', 'tilt=%.2f deg motion=%.3f g accel=%s' % (
                tilt, motion, accel))
        if tilt > config.MAX_TILT_DEG:
            if baseline:
                add('FAIL', 'Tilt deviation', '%.2f > %s deg from baseline' % (tilt, config.MAX_TILT_DEG))
            else:
                add('FAIL', 'Tilt limit', '%.2f > %s deg' % (tilt, config.MAX_TILT_DEG))
            return None
        if motion > config.MAX_MOTION_G:
            add('FAIL', 'Motion limit', '%.3f > %s g' % (motion, config.MAX_MOTION_G))
            return None
        return mpu
    except Exception as exc:
        add('FAIL', 'MPU6050', type(exc).__name__ + ': ' + str(exc))
        return None


def stage_gps():
    print('\n-- Stage 6: GPS UART --')
    if not config.GPS_ENABLED:
        add('SKIP', 'GPS', 'disabled in config')
        return False
    gps = None
    try:
        from machine import UART, Pin
        from gps import GPS
        uart = UART(1, config.GPS_BAUD, tx=Pin(pins.GPS_UART_TX),
                    rx=Pin(pins.GPS_UART_RX), rxbuf=2048, timeout=0)
        gps = GPS(uart, config.GPS_STALE_MS)
        deadline = time.ticks_add(time.ticks_ms(), GPS_READ_MS)
        while time.ticks_diff(deadline, time.ticks_ms()) > 0:
            gps.poll()
            if gps.status()['fix_valid']:
                break
            time.sleep_ms(20)
        status = gps.status()
        fix = gps.location()
        add('INFO', 'GPS status', 'nmea=%s fix=%s state=%s malformed=%s' % (
            status['nmea_received'], status['fix_valid'], status['state'],
            status['malformed']))
        if status['fix_valid'] and fix:
            add('PASS', 'GPS valid fix', 'lat=%.6f lon=%.6f utc=%s' % (
                fix['latitude'], fix['longitude'], fix['utc']))
            return True
        if status['nmea_received']:
            add('PASS', 'GPS NMEA reception', 'serial data valid; no current fix')
            add('BLOCKED', 'GPS fix', 'NMEA is not a fix; antenna/view required')
            return True
        add('FAIL', 'GPS NMEA reception', 'no checksum-valid sentence in %d ms' % GPS_READ_MS)
        return False
    except Exception as exc:
        add('FAIL', 'GPS UART', type(exc).__name__ + ': ' + str(exc))
        return False
    finally:
        if gps is not None:
            try:
                gps.close()
            except Exception:
                pass


def calibration_gaps():
    missing = []
    # Core load-cell params always required
    for name in ('LOAD_OFFSET', 'LOAD_SCALE', 'STABILITY_G'):
        value = attr(name)
        if value is None or not finite(value):
            missing.append(name)
    if finite(attr('LOAD_SCALE')) and attr('LOAD_SCALE') == 0:
        missing.append('LOAD_SCALE(nonzero)')
    # Cup-related params only required if cup sensor is enabled
    if getattr(config, 'CUP_SENSOR_REQUIRED', False) or getattr(config, 'HC_SR04_ENABLED', False):
        for name in ('EMPTY_CUP_G', 'EMPTY_CUP_TOLERANCE_G', 'DELTA_TOLERANCE_G'):
            value = attr(name)
            if value is None or not finite(value):
                missing.append(name)
        window = attr('CUP_DISTANCE_CM')
        if window is None:
            missing.append('CUP_DISTANCE_CM')
        elif (not isinstance(window, (list, tuple)) or len(window) != 2 or
                not all(finite(v) for v in window) or not 0 <= window[0] < window[1]):
            missing.append('CUP_DISTANCE_CM(range)')
    else:
        # HC-SR04 disabled: skip cup-related params
        pass
    for slot in SEQUENCE_SLOTS:
        table = attr('EXPECTED_DELTA_G', {}) or {}
        if not finite(table.get(slot)) or table.get(slot) <= 0:
            missing.append('EXPECTED_DELTA_G[%s]' % slot)
    return missing


def stage_hx711():
    print('\n-- Stage 7: HX711 and calibration --')
    import uasyncio as asyncio
    from hx711 import HX711
    hx = None
    raw_ok = False
    try:
        hx = HX711(pins.HX_DATA, pins.HX_CLOCK, config.HX_TIMEOUT_MS)
        async def take_samples():
            try:
                return await hx.samples(5)
            finally:
                hx.clock.value(0)
        raw = asyncio.run(take_samples())
        mean = sum(raw) / len(raw)
        spread = max(raw) - min(raw)
        if spread > 50000:
            add('FAIL', 'HX711 stability', 'counts=%.1f spread=%.1f; check HX711 '
                'power, data/clock wiring and load cell' % (mean, spread))
        elif spread == 0 and abs(mean) < 10:
            add('FAIL', 'HX711 data line', 'constant %.1f counts with zero spread; '
                'check HX711 power, data/clock wiring and load cell' % mean)
        else:
            add('PASS', 'HX711 raw sample', 'counts=%.1f spread=%.1f' % (mean, spread))
            raw_ok = True
    except Exception as exc:
        add('FAIL', 'HX711 raw sample', type(exc).__name__ + ': ' + str(exc))
    missing = calibration_gaps()
    if missing:
        add('BLOCKED', 'Load-cell calibration', 'missing: ' + ', '.join(missing))
        return raw_ok, False
    add('PASS', 'Load-cell calibration fields', 'values present; physical mass check still required')
    return raw_ok, True


def stage_echo(echo_safe):
    print('\n-- Stage 8: HC-SR04 ECHO protection --')
    if not config.HC_SR04_ENABLED:
        add('SKIP', 'HC-SR04', 'disabled in config')
        return None
    safe = bool(echo_safe or config.HC_SR04_ECHO_3V3_SAFE)
    if not safe:
        add('BLOCKED', 'HC-SR04', 'ECHO protection not confirmed; TRIG was not pulsed')
        return None
    from hcsr04 import HCSR04
    sensor = None
    try:
        sensor = HCSR04(pins.ULTRA_TRIG, pins.ULTRA_ECHO)
        readings = []
        for _ in range(3):
            try:
                value = sensor.distance()
                if finite(value) and 2.0 <= value <= 400.0:
                    readings.append(value)
            except Exception:
                pass
            time.sleep_ms(100)
        if not readings:
            add('FAIL', 'HC-SR04', 'no usable echo; check target and divider')
            return False
        add('PASS', 'HC-SR04 distance', 'cm=' + ','.join('%.1f' % v for v in readings))
        window = attr('CUP_DISTANCE_CM')
        if window is None:
            add('BLOCKED', 'Cup detection window', 'CUP_DISTANCE_CM is None')
        else:
            inside = window[0] <= sum(readings) / len(readings) <= window[1]
            add('PASS' if inside else 'FAIL', 'Cup detection', 'window=%s' % (window,))
        return True
    except Exception as exc:
        add('FAIL', 'HC-SR04', type(exc).__name__ + ': ' + str(exc))
        return False
    finally:
        if sensor is not None:
            try:
                sensor.trig.off()
            except Exception:
                pass


def stage_safety_clock():
    print('\n-- Stage 9: safety manager and trusted clock --')
    from clock import Clock
    from usb_clock import parse_time_line
    clock = Clock(config.MAX_CLOCK_AGE_S)
    add('BLOCKED' if not clock.trusted() else 'PASS', 'Trusted clock', 'trusted=%s' % clock.trusted())
    add('INFO', 'Clock source', 'main.py accepts USB TIME,<epoch> when USB_TIME_SYNC_ENABLED=True; '
        'mpremote owns COM5 during this test, so no USB sync can occur here.')
    if parse_time_line('TIME,1791851400') == 1791851400 and parse_time_line('TIME,0') is None and parse_time_line('bad') is None:
        add('PASS', 'USB time parser', 'valid epoch accepted; invalid lines rejected')
    else:
        add('FAIL', 'USB time parser', 'parser self-check failed')
    class FakeJournal:
        fault = None
        events = []
    sample = dict(faults=[], cup_present=True, lid_closed=None,
                  docked=False, tilt_deg=0.0, motion_g=0.0)
    reason = preflight(config, sample, False, FakeJournal())
    if reason == 'Clock untrusted':
        add('PASS', 'Safety manager fail-closed', 'untrusted clock rejected')
    else:
        add('FAIL', 'Safety manager fail-closed', reason or 'unexpected acceptance')
    reason = interlocks(config, sample)
    if config.LID_INTERLOCK_REQUIRED and config.LIMIT_SWITCH_ROLE != 'lid_closed':
        if reason:
            add('PASS', 'Lid interlock fail-closed', reason)
        else:
            add('FAIL', 'Lid interlock fail-closed', 'missing lid input was accepted')
    else:
        add('INFO', 'Lid interlock fail-closed', reason or 'no lid requirement')
    add('INFO', 'Reminder rule', 'scheduler reminders and daily_auto require clock.trusted()')
    return clock


def _servo_label(sid):
    return '%d (%s)' % (sid, config.SERVOS[sid]['role'])


def _servo_ready(sid):
    settings = config.SERVOS[sid]
    if sid == 4:
        return False, 'Servo 4 docking disabled'
    if not settings.get('calibrated'):
        return False, 'per-servo calibrated=False'
    if sid == 1:
        for name in ('PORTABLE_CLOSED_ANGLE', 'PORTABLE_OPEN_ANGLE'):
            value = attr(name)
            if not finite(value) or not settings['min_angle'] <= value <= settings['max_angle']:
                return False, name + ' missing or outside limits'
    if sid == 3:
        angles = attr('STORAGE_ANGLES', ())
        if len(angles) != 5 or any(not finite(a) for a in angles):
            return False, 'five STORAGE_ANGLES required'
    return True, 'ready'


def _ramp(bank, sid, start, end, step, pause_ms):
    start = int(start)
    end = int(end)
    step = max(1, int(step))
    bank.move_angle(sid, start)
    time.sleep_ms(pause_ms)
    direction = 1 if end >= start else -1
    angle = start
    while (angle + direction * step) * direction <= end * direction:
        angle += direction * step
        bank.move_angle(sid, angle)
        time.sleep_ms(pause_ms)
    if angle != end:
        bank.move_angle(sid, end)
        time.sleep_ms(pause_ms)


def _countdown(seconds, label):
    for remaining in range(seconds, 0, -1):
        print('  %s in %d s (Ctrl-C aborts)' % (label, remaining))
        time.sleep(1)


def _confirm(question):
    try:
        return input(question + ' Type YES: ').strip().upper() == 'YES'
    except EOFError:
        return False


def stage_servos(environment_ok, motion_reason, supervised, interactive):
    print('\n-- Stage 10: individual servo verification --')
    from servo_controller import ServoBank
    try:
        bank = ServoBank(config)
        add('PASS', 'Servo configuration and channel map')
    except Exception as exc:
        add('FAIL', 'Servo configuration', type(exc).__name__ + ': ' + str(exc))
        return None, {}
    ready = {}
    for sid in (1, 2, 3, 4):
        settings = config.SERVOS[sid]
        ok, why = _servo_ready(sid)
        ready[sid] = ok
        add('INFO', 'Servo %s' % _servo_label(sid),
            'GP%d %d..%d us %s..%s deg calibrated=%s -> %s' % (
                pins.SERVO_PINS[sid - 1], settings['min_us'], settings['max_us'],
                settings['min_angle'], settings['max_angle'],
                settings.get('calibrated'), why))
        if sid == 4:
            add('SKIP', 'Servo 4 dock flap', 'disabled; never commanded in this test')
        elif not ok:
            add('BLOCKED', 'Servo %d movement' % sid, why)
    if not (supervised == SUPERVISED_TOKEN):
        add('BLOCKED', 'Supervised servo motion',
            'pass supervised="%s" only after confirming empty compartments, '
            'clear mechanics and external servo power' % SUPERVISED_TOKEN)
        return bank, ready
    if not environment_ok:
        add('BLOCKED', 'Supervised servo motion', motion_reason)
        return bank, ready
    if not (ready.get(1) or ready.get(2)):
        add('BLOCKED', 'Supervised servo motion', 'no servo has complete calibration')
        return bank, ready
    try:
        _countdown(5, 'Servo motion')
        if ready.get(1):
            closed = int(attr('PORTABLE_CLOSED_ANGLE'))
            opened = int(attr('PORTABLE_OPEN_ANGLE'))
            add('INFO', 'Servo 1 test', 'portable flap closed -> open -> closed')
            _ramp(bank, 1, closed, opened, 10, STEP_PAUSE_MS)
            time.sleep_ms(MOVE_DWELL_MS)
            _ramp(bank, 1, opened, closed, 10, STEP_PAUSE_MS)
            time.sleep_ms(MOVE_DWELL_MS)
            add('INFO', 'Servo 1 commanded', 'physical observation not recorded')
            if interactive and _confirm('Did servo 1 move correctly?'):
                add('PASS', 'Servo 1 observed', 'operator confirmed')
            else:
                add('BLOCKED', 'Servo 1 observation', 'operator confirmation not recorded')
            bank.stop()
        if ready.get(2):
            lo = int(config.SERVOS[2]['min_angle'])
            hi = int(config.SERVOS[2]['max_angle'])
            span = hi - lo
            targets = (lo + span // 4, lo + span // 2, lo + 3 * span // 4, lo)
            add('INFO', 'Servo 2 test', 'daily rotation 25/50/75 percent then return to min')
            previous = lo
            for target in targets:
                _ramp(bank, 2, previous, target, 10, STEP_PAUSE_MS)
                previous = target
                time.sleep_ms(MOVE_DWELL_MS)
            add('INFO', 'Servo 2 commanded', 'physical observation not recorded')
            if interactive and _confirm('Did servo 2 rotate correctly?'):
                add('PASS', 'Servo 2 observed', 'operator confirmed')
            else:
                add('BLOCKED', 'Servo 2 observation', 'operator confirmation not recorded')
            bank.stop()
    except KeyboardInterrupt:
        add('FAIL', 'Servo motion aborted', 'operator interrupted')
    except Exception as exc:
        add('FAIL', 'Servo motion', type(exc).__name__ + ': ' + str(exc))
    finally:
        try:
            bank.stop()
        except Exception:
            pass
    return bank, ready


def stage_sequence_positions(bank, ready, environment_ok, lid_ok, cup_ok, release_reason,
                             supervised, interactive, limit_switch):
    print('\n-- Stage 11: selector positions and daily sequences --')
    if bank is None:
        add('BLOCKED', 'Selector positions', 'servo bank unavailable')
        return
    if not ready.get(3):
        add('BLOCKED', 'Servo 3 five positions', 'Servo 3 is not calibrated')
    elif not environment_ok or not lid_ok:
        add('BLOCKED', 'Servo 3 five positions',
            'release-path safety prerequisites not met: ' + release_reason)
    elif not (supervised == SUPERVISED_TOKEN):
        add('BLOCKED', 'Servo 3 five positions', 'supervised motion not enabled')
    else:
        try:
            _countdown(5, 'Servo 3 position test')
            previous = int(config.STORAGE_ANGLES[0])
            for position in range(1, 6):
                target = int(bank.storage_angle(position))
                add('INFO', 'Servo 3 position %d' % position, 'target %d deg' % target)
                _ramp(bank, 3, previous, target, 6, STEP_PAUSE_MS)
                previous = target
                time.sleep_ms(MOVE_DWELL_MS)
                add('INFO', 'Servo 3 commanded', 'position %d; physical observation not recorded' % position)
                if interactive and not _confirm('Did position %d look correct?' % position):
                    add('BLOCKED', 'Servo 3 observation', 'operator did not confirm position %d' % position)
                    break
            add('INFO', 'Servo 3 stopped', 'PWM released after position test')
        except KeyboardInterrupt:
            add('FAIL', 'Servo 3 motion aborted', 'operator interrupted')
        except Exception as exc:
            add('FAIL', 'Servo 3 motion', type(exc).__name__ + ': ' + str(exc))
        finally:
            try:
                bank.stop()
            except Exception:
                pass
    nonempty = []
    for slot in SEQUENCE_SLOTS:
        seq = config.SERVO_SEQUENCES.get(slot, ())
        if seq:
            nonempty.append(slot)
            try:
                bank.validate(slot)
                add('PASS', 'Sequence %s validates' % slot, '%d steps' % len(seq))
            except Exception as exc:
                add('BLOCKED', 'Sequence %s' % slot, str(exc))
        else:
            add('BLOCKED', 'Sequence %s' % slot, 'no steps configured')
    if not nonempty:
        add('BLOCKED', 'Daily compartment sequence', 'SERVO_SEQUENCES is empty')
        return
    if not config.ACTUATION_VERIFIED:
        add('BLOCKED', 'Daily compartment sequence run', 'ACTUATION_VERIFIED is False')
        return
    if not environment_ok or not lid_ok or not cup_ok:
        add('BLOCKED', 'Daily compartment sequence run', release_reason)
        return
    if not (supervised == SUPERVISED_TOKEN):
        add('BLOCKED', 'Daily compartment sequence run', 'supervised motion not enabled')
        return
    slot = nonempty[0]
    add('INFO', 'Daily sequence run', 'slot %s only; observe every step' % slot)
    import uasyncio as asyncio
    async def guard():
        if limit_switch is None:
            return False
        state = limit_switch.state()
        return bool(state['ready']) and state['active'] is False
    try:
        _countdown(5, 'Daily sequence')
        asyncio.run(bank.release(slot, guard))
        add('INFO', 'Daily sequence commanded', 'physical observation not recorded')
        if interactive and _confirm('Did the daily sequence complete correctly?'):
            add('PASS', 'Daily sequence observed', 'operator confirmed')
        else:
            add('BLOCKED', 'Daily sequence observation', 'operator confirmation not recorded')
    except KeyboardInterrupt:
        add('FAIL', 'Daily sequence aborted', 'operator interrupted')
    except Exception as exc:
        add('FAIL', 'Daily sequence', type(exc).__name__ + ': ' + str(exc))
    finally:
        try:
            bank.stop()
        except Exception:
            pass


def commissioning_gaps():
    gaps = []
    if not config.WIRING_VERIFIED:
        gaps.append('WIRING_VERIFIED=False')
    if not config.ACTUATION_VERIFIED:
        gaps.append('ACTUATION_VERIFIED=False: no supervised actuator verification recorded')
    if not config.CALIBRATED:
        gaps.append('CALIBRATED=False: load-cell/cup calibration incomplete')
    missing = calibration_gaps()
    if missing:
        gaps.append('Missing calibration values: ' + ', '.join(missing))
    for sid in (1, 2, 3):
        settings = config.SERVOS.get(sid, {})
        if not settings.get('calibrated'):
            gaps.append('Servo %d (%s) calibrated=False' % (sid, settings.get('role', '?')))
    if finite(attr('PORTABLE_CLOSED_ANGLE')) and finite(attr('PORTABLE_OPEN_ANGLE')):
        lo = config.SERVOS[1]['min_angle']
        hi = config.SERVOS[1]['max_angle']
        for name in ('PORTABLE_CLOSED_ANGLE', 'PORTABLE_OPEN_ANGLE'):
            value = attr(name)
            if not lo <= value <= hi:
                gaps.append('%s=%s outside servo 1 limits %s..%s' % (name, value, lo, hi))
    else:
        gaps.append('PORTABLE_CLOSED_ANGLE/PORTABLE_OPEN_ANGLE not both set')
    if not any(config.SERVO_SEQUENCES.get(slot) for slot in SEQUENCE_SLOTS):
        gaps.append('SERVO_SEQUENCES empty: no release path is configured')
    if config.LID_INTERLOCK_REQUIRED and config.LIMIT_SWITCH_ROLE != 'lid_closed':
        gaps.append('LID_INTERLOCK_REQUIRED=True but LIMIT_SWITCH_ROLE=%s; '
                    'no lid sensor is wired' % config.LIMIT_SWITCH_ROLE)
    if config.HC_SR04_ENABLED and not config.HC_SR04_ECHO_3V3_SAFE:
        gaps.append('HC_SR04_ECHO_3V3_SAFE=False: GP5 ECHO protection unconfirmed; TRIG stays off')
    if not config.BUZZER_ENABLED:
        gaps.append('BUZZER_ENABLED=False: GP14 is not connected; no audible alert')
    gaps.append('Servo 4 (dock_flap) remains disabled; docking was not tested')
    return gaps


def stage_report():
    print('\n-- Stage 12: final report --')
    counts = {}
    for status, _, _ in RESULTS:
        counts[status] = counts.get(status, 0) + 1
    if counts.get('FAIL'):
        overall = 'FAIL'
    elif counts.get('BLOCKED'):
        overall = 'BLOCKED'
    else:
        overall = 'PASS'
    print('\n================ FINAL REPORT ================')
    print('OVERALL:', overall)
    print('PASS=%d FAIL=%d BLOCKED=%d SKIP=%d INFO=%d' % (
        counts.get('PASS', 0), counts.get('FAIL', 0), counts.get('BLOCKED', 0),
        counts.get('SKIP', 0), counts.get('INFO', 0)))
    print('\nBlocking items:')
    seen = set()
    for item in BLOCKERS:
        if item not in seen:
            seen.add(item)
            print(' -', item)
    print('\nCommissioning flags: wiring=%s calibration=%s actuation=%s' % (
        config.WIRING_VERIFIED, config.CALIBRATED, config.ACTUATION_VERIFIED))
    print('\nCommissioning gaps (exact):')
    for gap in commissioning_gaps():
        print(' -', gap)
    print('\nServo 4: disabled; docking was not tested.')
    print('Buzzer: not connected; no audible-alert claim is made.')
    print('No flags were changed and no medication was dispensed.')
    print('PASS on a communication read is not physical calibration.')
    print('Physical checks still require observation and, for actuation,')
    print('explicit operator confirmation before any flag is recorded.')
    lines = []
    for status, name, detail in RESULTS:
        lines.append('[%s] %s%s' % (status, name, (' - ' + str(detail)) if detail else ''))
    lines.append('OVERALL: ' + overall)
    try:
        with open('sequential_report.txt', 'w') as handle:
            handle.write('\n'.join(lines) + '\n')
        print('Report written: sequential_report.txt')
    except Exception as exc:
        print('Report file not written:', type(exc).__name__)
    return overall


def run(read_only=True, echo_safe=False, supervised=None, interactive=None):
    print('\n==============================================')
    print(' MED GUARDIAN SEQUENTIAL TEST')
    print(' Read-only default; empty compartments only')
    print('==============================================')
    if interactive is None:
        interactive = supervised is not None
    if supervised is not None and supervised != SUPERVISED_TOKEN:
        print('Supervised token mismatch; motion stays blocked.')
    if not stage_imports():
        return stage_report()
    if not stage_pins():
        return stage_report()
    stage_schedule()
    limit_switch, limit_ok = stage_limit(interactive and not read_only)
    mpu = stage_mpu()
    motion_sensor_ok = mpu is not None or not config.MOTION_SENSOR_REQUIRED
    stage_gps()
    hx_ok, calibration_ok = stage_hx711()
    echo_ok = stage_echo(echo_safe)
    stage_safety_clock()
    motion_missing = []
    if not limit_ok:
        motion_missing.append('limit switch not ready or unit is docked')
    if not motion_sensor_ok:
        motion_missing.append('motion sensor required but unavailable')
    if not hx_ok:
        motion_missing.append('HX711 raw read failed')
    if not calibration_ok:
        motion_missing.append('load-cell/cup calibration incomplete')
    environment_ok = not motion_missing
    motion_reason = '; '.join(motion_missing) or 'ok'
    lid_ok = (not config.LID_INTERLOCK_REQUIRED or
              config.LIMIT_SWITCH_ROLE == 'lid_closed')
    cup_ok = (not config.CUP_SENSOR_REQUIRED or
              bool(config.HC_SR04_ENABLED and config.HC_SR04_ECHO_3V3_SAFE and
                   echo_ok and isinstance(config.CUP_DISTANCE_CM, (list, tuple)) and
                   len(config.CUP_DISTANCE_CM) == 2))
    release_missing = list(motion_missing)
    if not lid_ok:
        release_missing.append('lid interlock input missing (LIMIT_SWITCH_ROLE=%s)' %
                               config.LIMIT_SWITCH_ROLE)
    if not cup_ok:
        release_missing.append('cup sensor/ECHO protection unavailable')
    release_reason = '; '.join(release_missing) or 'ok'
    bank, ready = stage_servos(environment_ok, motion_reason,
                               supervised if not read_only else None, interactive)
    stage_sequence_positions(bank, ready, environment_ok, lid_ok, cup_ok,
                             release_reason, supervised if not read_only else None,
                             interactive, limit_switch)
    if bank is not None:
        try:
            bank.stop()
        except Exception:
            pass
    return stage_report()


def main():
    run(read_only=True)


if __name__ == '__main__':
    main()
