# Raw PWM test for Servo 3 (GP20) and Servo 4 (GP21)
# Bypasses all config and servo controller — direct machine.PWM
from machine import Pin, PWM
import time

print('=== RAW PWM TEST: Servo 3 & 4 ===')
print()

# Servo 3: GP20
print('--- Servo 3 (GP20) ---')
try:
    pwm20 = PWM(Pin(20), freq=50)
    print('  PWM created on GP20')
    
    # Standard servo pulse widths: 1000us=0deg, 1500us=90deg, 2000us=180deg
    # duty_u16 range: 0-65535 maps to 0-20000us at freq=50
    # 1000us = 1000/20000 * 65535 = 3277
    # 1500us = 1500/20000 * 65535 = 4915
    # 2000us = 2000/20000 * 65535 = 6554
    
    print('  Sending 1500us (center/stop) ...')
    pwm20.duty_u16(4915)
    time.sleep(2)
    
    print('  Sending 1000us (0 deg / full left) ...')
    pwm20.duty_u16(3277)
    time.sleep(2)
    
    print('  Sending 2000us (180 deg / full right) ...')
    pwm20.duty_u16(6554)
    time.sleep(2)
    
    print('  Sending 1500us (center/stop) ...')
    pwm20.duty_u16(4915)
    time.sleep(1)
    
    pwm20.duty_u16(0)
    pwm20.deinit()
    print('  Stopped')
except Exception as e:
    print('  ERROR:', e)
print()

# Servo 4: GP21
print('--- Servo 4 (GP21) ---')
try:
    pwm21 = PWM(Pin(21), freq=50)
    print('  PWM created on GP21')
    
    print('  Sending 1000us (closed) ...')
    pwm21.duty_u16(3277)
    time.sleep(1)
    
    print('  Sending 2000us (opened) ...')
    pwm21.duty_u16(6554)
    time.sleep(1)
    
    print('  Sending 1000us (closed) ...')
    pwm21.duty_u16(3277)
    time.sleep(1)
    
    pwm21.duty_u16(0)
    pwm21.deinit()
    print('  Stopped')
except Exception as e:
    print('  ERROR:', e)
print()

print('=== RAW PWM TEST COMPLETE ===')
print()
print('If Servo 3 still does not move:')
print('  - Check signal wire on Pico physical pin 26 (GP20)')
print('  - Check VCC (red) and GND (brown) connections')
print('  - Try swapping signal wire with Servo 1 to isolate the fault')
print()
print('If Servo 4 still does not move:')
print('  - Check signal wire on Pico physical pin 27 (GP21)')
print('  - Check VCC (red) and GND (brown) connections')
