import math
class MPU6050:
    def __init__(self,i2c,address=0x68,baseline=None):
        self.i2c=i2c; self.address=address
        if self.i2c.readfrom_mem(address,0x75,1)[0]!=0x68: raise OSError('MPU6050 identity mismatch')
        self.i2c.writeto_mem(address,0x6B,b'\x00')
        self.i2c.writeto_mem(address,0x1C,b'\x00')
        self.baseline = baseline  # (bx, by, bz) baseline acceleration vector
    def read(self):
        b=self.i2c.readfrom_mem(self.address,0x3B,6)
        a=[]
        for i in (0,2,4):
            v=b[i]*256+b[i+1]; a.append((v-65536 if v&32768 else v)/16384)
        x,y,z=a; magnitude=math.sqrt(x*x+y*y+z*z)
        if magnitude<0.1: raise OSError('Acceleration invalid')
        if self.baseline is not None:
            # Calculate deviation from baseline orientation
            bx,by,bz = self.baseline
            bmag = math.sqrt(bx*bx+by*by+bz*bz)
            if bmag < 0.1:
                tilt = math.acos(max(-1,min(1,z/magnitude)))*180/math.pi
            else:
                # Dot product of normalized vectors gives cosine of angle between them
                dot = (x*bx + y*by + z*bz) / (magnitude * bmag)
                tilt = math.acos(max(-1,min(1,dot)))*180/math.pi
        else:
            tilt = math.acos(max(-1,min(1,z/magnitude)))*180/math.pi
        return tilt,abs(magnitude-1),a
