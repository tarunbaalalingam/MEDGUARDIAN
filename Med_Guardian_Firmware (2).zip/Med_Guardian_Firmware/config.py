# Deployed configuration for the plain RP2040 Pico on COM5.
# Wiring was declared complete and the static pin map validates; calibration and
# actuation remain unverified and must not be inferred from that declaration.
DEVICE_ID = 'nestiq-01'
DEVICE_KEY = 'e913bce484fc5f1b005b516f1bc921f8878b419b64d4fccef1f33a0bfc169edf'
SSID = 'POCO C81'
WIFI_PASSWORD = '123456790'
SERVER_HOST = '192.168.1.1'
SERVER_PORT = 8080
ALLOW_LAN_HTTP = True  # Existing signed HTTP protocol; isolated trusted LAN.
NETWORK_ENABLED = True
NETWORK_TRANSPORT = 'esp_at'  # Preserve supplied architecture, not native CYW43.
ESP_BAUD = 115200
WIRING_VERIFIED = True  # Operator declared wiring complete; static map checks passed.
ACTUATION_VERIFIED = False  # No supervised actuator verification recorded.
CALIBRATED = True  # HX711 load cell calibrated (LOAD_OFFSET, LOAD_SCALE, STABILITY_G set).
USB_TIME_SYNC_ENABLED = True  # Trusted UTC epoch over USB ("TIME,<epoch>").

# Nominal endpoints only: measure pulse ranges and mechanical limits separately.
# Adjacent servos share RP2040 PWM slices and MUST use the same frequency.
SERVOS = {
    1: dict(role='portable_flap', min_us=1000, max_us=2000, frequency=50,
            travel_deg=180, min_angle=0, max_angle=180, calibrated=True),
    2: dict(role='daily_rotation', min_us=1000, max_us=2000, frequency=50,
            travel_deg=180, min_angle=0, max_angle=180, calibrated=True),
    3: dict(role='storage_rotation', min_us=1000, max_us=2000, frequency=50,
            travel_deg=360, min_angle=0, max_angle=360, calibrated=True),
    4: dict(role='dock_flap', min_us=1000, max_us=2000, frequency=50,
            travel_deg=180, min_angle=0, max_angle=180, calibrated=True),
}
SERVO3_POSITION_MODE_CONFIRMED = True  # User confirmed positional 360-degree unit.
STORAGE_ANGLES = (0, 72, 144, 216, 288)  # Positions 1..5, no wrapping across 360.
PORTABLE_OPEN_ANGLE = 90   # Measure and adjust to your mechanical stop.
PORTABLE_CLOSED_ANGLE = 0  # Measure and adjust to your mechanical stop.
DOCK_OPEN_ANGLE = 0
DOCK_CLOSED_ANGLE = 90
# Servo 4 supports local supervised diagnostics only. Portable dispensing never
# uses a dock or Servo 4. This switch enables ONLY the local diagnostic API.
DOCK_DIAGNOSTICS_ENABLED = True  # Enabled for local supervised diagnostics.

# Preserve schedule slot names, but do not equate slot names with servo roles.
# New sequences can coordinate multiple servos with dictionaries:
# {'servo': 3, 'position': 2, 'dwell_ms': measured_ms}
# {'servo': 1, 'angle': measured_angle, 'dwell_ms': measured_ms}
# End with a mechanically safe return path. No release path is invented here.
# Compartment 1 = morning, 2 = afternoon, 3 = night.
# Each sequence: Servo 3 rotates to compartment, Servo 1 opens flap, waits, closes flap.
# STORAGE_ANGLES: position 1=0°, 2=72°, 3=144°, 4=216°, 5=288°
SERVO_SEQUENCES = {
    'morning': [
        {'servo': 3, 'position': 1, 'dwell_ms': 2000},   # Rotate to compartment 1 (0°)
        {'servo': 1, 'angle': 90, 'dwell_ms': 3000},      # Open flap for 3 seconds
        {'servo': 1, 'angle': 0, 'dwell_ms': 2000},       # Close flap
    ],
    'afternoon': [
        {'servo': 3, 'position': 2, 'dwell_ms': 2000},    # Rotate to compartment 2 (72°)
        {'servo': 1, 'angle': 90, 'dwell_ms': 3000},      # Open flap for 3 seconds
        {'servo': 1, 'angle': 0, 'dwell_ms': 2000},       # Close flap
    ],
    'night': [
        {'servo': 3, 'position': 3, 'dwell_ms': 2000},    # Rotate to compartment 3 (144°)
        {'servo': 1, 'angle': 90, 'dwell_ms': 3000},      # Open flap for 3 seconds
        {'servo': 1, 'angle': 0, 'dwell_ms': 2000},       # Close flap
    ],
}
# For migration only: legacy [(pulse_us, dwell_ms), ...] uses this slot->ID map.
SERVO_ROLE_MAP = {}
WEIGHT_SETTLE_MS = 500  # Commission with actual settling time.

LIMIT_SWITCH_ACTIVE = 0  # COM -> GND, NO -> GP16, internal pull-up.
LIMIT_DEBOUNCE_MS = 50
LIMIT_SWITCH_ROLE = 'docked'  # User confirmed: activated while attached to dock.
DOCK_SENSOR_REQUIRED = True
LID_INTERLOCK_REQUIRED = False  # No lid sensor is wired; limit switch is 'docked'.
# These sensors existed in the supplied project; disable only after reviewing
# their safety role. Required disabled sensors block dispensing, not startup.
HC_SR04_ENABLED = False  # User is not using the ultrasonic sensor.
HC_SR04_ECHO_3V3_SAFE = False  # Not applicable; HC-SR04 disabled.
MPU6050_ENABLED = True
BUZZER_ENABLED = False  # GP14 is not connected on this unit; no audible alert.
CUP_SENSOR_REQUIRED = False  # HC-SR04 disabled; cup check not applicable.
MOTION_SENSOR_REQUIRED = True
LOAD_OFFSET = -192838  # Recalibrated: empty platform, 10 samples avg, spread=140.
LOAD_SCALE = -346.3  # signed counts/gram, calibrated with 6.5g (10 rupee coin).
STABILITY_G = 2.0  # Weight must be stable within 2g for 500ms.
EMPTY_CUP_G = None  # Not applicable; HC-SR04 disabled.
EMPTY_CUP_TOLERANCE_G = None  # Not applicable; HC-SR04 disabled.
EXPECTED_DELTA_G = {'morning': 0.5, 'afternoon': 0.5, 'night': 0.5}  # Default: 0.5g per dose. Measure actual medication weight and adjust.
DELTA_TOLERANCE_G = 1.0  # Allow ±1g tolerance for medication weight.
CUP_DISTANCE_CM = None  # Not applicable; HC-SR04 disabled.
# MPU6050 baseline: updated to current position (dispenser disassembled for testing).
MPU_BASELINE_X = -0.495
MPU_BASELINE_Y = 0.339
MPU_BASELINE_Z = 1.010
MAX_TILT_DEG = 50  # Temporarily raised for servo test; restore after baseline update.
MAX_MOTION_G = 0.30  # Raised from 0.10: MPU6050 baseline magnitude is 1.215g, not 1.0g.
HX_TIMEOUT_MS = 1000
SENSOR_MAX_AGE_MS = 2000
GPS_ENABLED = False  # NEO-6M module is faulty: powered (LED solid) but no data output. Replace module.
GPS_BAUD = 9600  # NEO-6M default baud rate.
GPS_STALE_MS = 5000
TIMEZONE_MINUTES = 330
MAX_CLOCK_AGE_S = 86400
# Schedules remain reminders only; dispensing requires a current app command.
