# Standalone servo test — bypasses HX711/MPU6050 prerequisites.
# Tests Servo 1 (portable flap), Servo 2 (daily rotation), Servo 3 (5-position selector), Servo 4 (dock flap).
# WARNING: Ensure external 5V servo power is connected and compartments are empty.

import time
import config
import pins
from servo_controller import ServoBank

SUPERVISED_TOKEN = 'EMPTY-COMPARTMENTS-AREA-CLEAR'
STEP_PAUSE_MS = 300
MOVE_DWELL_MS = 1500


def ramp(bank, sid, start, end, step, pause_ms):
    start = int(start)
    end = int(end)
    step = max(1, int(step))
    bank.move_angle(sid, start)
    time.sleep_ms(pause_ms)
    direction = 1 if end >= start else -1
    angle = start
    while (angle + direction * step) * direction <= end * direction:
        angle += direction * step
        bank.move_angle(sid, angle)
        time.sleep_ms(pause_ms)
    if angle != end:
        bank.move_angle(sid, end)
        time.sleep_ms(pause_ms)


def countdown(seconds, label):
    for remaining in range(seconds, 0, -1):
        print('  %s in %d s (Ctrl-C aborts)' % (label, remaining))
        time.sleep(1)


def confirm(question):
    try:
        return input(question + ' Type YES: ').strip().upper() == 'YES'
    except EOFError:
        return False


def run(supervised=None, interactive=None):
    print('\n==============================================')
    print(' SERVO-ONLY TEST (bypasses HX711/MPU6050)')
    print(' All 4 servos tested')
    print('==============================================')

    if interactive is None:
        interactive = supervised is not None

    # Check supervised token
    if supervised != SUPERVISED_TOKEN:
        print('\n[FAIL] Supervised token required.')
        print('Run with: supervised="%s"' % SUPERVISED_TOKEN)
        print('Only after confirming: empty compartments, clear mechanics, external servo power.')
        return

    # Build servo bank
    try:
        bank = ServoBank(config)
        print('[PASS] Servo bank initialized')
    except Exception as exc:
        print('[FAIL] Servo bank: %s' % exc)
        return

    try:
        # ---- Servo 1: Portable flap ----
        print('\n--- Servo 1: Portable flap ---')
        s1 = config.SERVOS[1]
        print('  Pin: GP%d, Range: %d..%d us, %d..%d deg' % (
            pins.SERVO_PINS[0], s1['min_us'], s1['max_us'], s1['min_angle'], s1['max_angle']))

        closed = int(config.PORTABLE_CLOSED_ANGLE)
        opened = int(config.PORTABLE_OPEN_ANGLE)
        print('  Test: closed(%d) -> open(%d) -> closed(%d)' % (closed, opened, closed))

        countdown(5, 'Servo 1 motion')
        ramp(bank, 1, closed, opened, 10, STEP_PAUSE_MS)
        time.sleep_ms(MOVE_DWELL_MS)
        print('  Flap OPENED — observe movement')
        ramp(bank, 1, opened, closed, 10, STEP_PAUSE_MS)
        time.sleep_ms(MOVE_DWELL_MS)
        print('  Flap CLOSED')

        if interactive and confirm('Did servo 1 (portable flap) move correctly?'):
            print('[PASS] Servo 1 observed — operator confirmed')
        else:
            print('[BLOCKED] Servo 1 — operator confirmation not recorded')

        bank.stop()

        # ---- Servo 2: Daily rotation ----
        print('\n--- Servo 2: Daily compartment rotation ---')
        s2 = config.SERVOS[2]
        print('  Pin: GP%d, Range: %d..%d us, %d..%d deg' % (
            pins.SERVO_PINS[1], s2['min_us'], s2['max_us'], s2['min_angle'], s2['max_angle']))

        lo = int(s2['min_angle'])
        hi = int(s2['max_angle'])
        span = hi - lo
        targets = (lo + span // 4, lo + span // 2, lo + 3 * span // 4, lo)
        print('  Test: 25%%(%d) -> 50%%(%d) -> 75%%(%d) -> return(%d)' % targets)

        countdown(5, 'Servo 2 motion')
        previous = lo
        for target in targets:
            ramp(bank, 2, previous, target, 10, STEP_PAUSE_MS)
            previous = target
            time.sleep_ms(MOVE_DWELL_MS)
            print('  Rotated to %d deg — observe' % target)

        if interactive and confirm('Did servo 2 (daily rotation) rotate correctly?'):
            print('[PASS] Servo 2 observed — operator confirmed')
        else:
            print('[BLOCKED] Servo 2 — operator confirmation not recorded')

        bank.stop()

        # ---- Servo 3: Five-position selector ----
        print('\n--- Servo 3: Five-position storage selector ---')
        s3 = config.SERVOS[3]
        print('  Pin: GP%d, Range: %d..%d us, %d..%d deg' % (
            pins.SERVO_PINS[2], s3['min_us'], s3['max_us'], s3['min_angle'], s3['max_angle']))

        angles = config.STORAGE_ANGLES
        print('  Storage angles: %s' % str(angles))

        countdown(5, 'Servo 3 motion')
        previous = int(angles[0])
        all_confirmed = True
        for position in range(1, 6):
            target = int(angles[position - 1])
            print('  Position %d: target %d deg' % (position, target))
            ramp(bank, 3, previous, target, 6, STEP_PAUSE_MS)
            previous = target
            time.sleep_ms(MOVE_DWELL_MS)
            print('  Commanded position %d — observe' % position)
            if interactive and not confirm('Did position %d look correct?' % position):
                print('[BLOCKED] Servo 3 position %d — operator did not confirm' % position)
                all_confirmed = False
                break

        if all_confirmed:
            print('[PASS] Servo 3 five positions — operator confirmed all')
        else:
            print('[BLOCKED] Servo 3 — not all positions confirmed')

        bank.stop()

        # ---- Servo 4: Dock flap ----
        print('\n--- Servo 4: Dock flap ---')
        if config.DOCK_DIAGNOSTICS_ENABLED:
            s4 = config.SERVOS[4]
            print('  Pin: GP%d, Range: %d..%d us, %d..%d deg' % (
                pins.SERVO_PINS[3], s4['min_us'], s4['max_us'], s4['min_angle'], s4['max_angle']))
            print('  Diagnostics enabled: True')

            closed = int(config.DOCK_CLOSED_ANGLE)
            opened = 90
            print('  Test: closed(%d) -> open(%d) -> closed(%d)' % (closed, opened, closed))

            countdown(5, 'Servo 4 motion')
            bank = ServoBank(config)
            ramp(bank, 4, closed, opened, 10, STEP_PAUSE_MS)
            time.sleep_ms(MOVE_DWELL_MS)
            print('  Dock flap OPENED — observe movement')
            ramp(bank, 4, opened, closed, 10, STEP_PAUSE_MS)
            time.sleep_ms(MOVE_DWELL_MS)
            print('  Dock flap CLOSED')

            if interactive and confirm('Did servo 4 (dock flap) move correctly?'):
                print('[PASS] Servo 4 observed — operator confirmed')
            else:
                print('[BLOCKED] Servo 4 — operator confirmation not recorded')

            bank.stop()
        else:
            print('[SKIP] Servo 4 — docking diagnostics disabled in config')

        # ---- Summary ----
        print('\n==============================================')
        print(' SERVO TEST COMPLETE')
        print(' Servo 1 (portable flap): tested')
        print(' Servo 2 (daily rotation): tested')
        print(' Servo 3 (5-position selector): tested')
        if config.DOCK_DIAGNOSTICS_ENABLED:
            print(' Servo 4 (dock flap): tested')
        else:
            print(' Servo 4 (dock flap): SKIPPED')
        print('==============================================')
        print('\nNOTE: HX711 and MPU6050 were not tested in this run.')
        print('Fix sensor wiring and run full sequential_test.py for complete verification.')

    except KeyboardInterrupt:
        print('\n[FAIL] Servo motion aborted by operator')
    except Exception as exc:
        print('\n[FAIL] Servo motion error: %s' % exc)
    finally:
        try:
            bank.stop()
        except Exception:
            pass


def main():
    run()


if __name__ == '__main__':
    main()
