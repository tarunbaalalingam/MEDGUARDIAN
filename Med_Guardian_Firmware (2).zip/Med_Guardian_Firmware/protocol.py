"""Protocol v1: identical source used by host and Pico. No hardware imports."""
import json
import hashlib
import binascii
SLOTS = ('morning', 'afternoon', 'night')
EVENTS = ('reminder', 'snoozed', 'attempt', 'blocked', 'sensor_confirmed', 'uncertain', 'fault', 'command_received', 'reconciled')
def mac(key, data):
    key = key.encode() if isinstance(key, str) else key
    if len(key) > 64: key = hashlib.sha256(key).digest()
    key += b'\x00' * (64-len(key))
    inner = bytes(x ^ 54 for x in key)
    outer = bytes(x ^ 92 for x in key)
    return binascii.hexlify(hashlib.sha256(outer + hashlib.sha256(inner+data).digest()).digest()).decode()
def equal(a,b):
    if len(a)!=len(b): return False
    v=0
    for x,y in zip(a.encode(),b.encode()): v |= x^y
    return v==0

def schedule(value):
    if not isinstance(value, dict) or set(value)!=set(SLOTS): raise ValueError('Exactly three slots required')
    out={}
    for slot, t in value.items():
        if t is not None:
            if not isinstance(t,str) or len(t)!=5 or t[2]!=':' or not (t[:2]+t[3:]).isdigit(): raise ValueError('Use HH:MM or null')
            if int(t[:2])>23 or int(t[3:])>59: raise ValueError('Invalid time')
        out[slot]=t
    return out

def command(v):
    if not isinstance(v,dict) or set(v)!=set(('id','type','occurrence','expires')): raise ValueError('Invalid command fields')
    if v['type'] not in ('dispense','snooze'): raise ValueError('Unsupported command')
    if not isinstance(v['id'],str) or not 1<=len(v['id'])<=64: raise ValueError('Invalid command id')
    if not isinstance(v['occurrence'],str) or len(v['occurrence'])>40: raise ValueError('Invalid occurrence')
    if type(v['expires']) is not int: raise ValueError('Invalid expiry')
    return v

def event(v):
    if not isinstance(v,dict) or v.get('kind') not in EVENTS: raise ValueError('Invalid event')
    if type(v.get('seq')) is not int or v['seq']<1: raise ValueError('Invalid event sequence')
    if type(v.get('at')) is not int: raise ValueError('Invalid timestamp')
    if not isinstance(v.get('occurrence'),str) or len(v['occurrence'])>40: raise ValueError('Invalid occurrence')
    if not isinstance(v.get('detail'),str) or len(v['detail'])>240: raise ValueError('Invalid detail')
    return v
