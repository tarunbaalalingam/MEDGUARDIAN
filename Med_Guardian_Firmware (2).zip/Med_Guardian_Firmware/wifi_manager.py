"""ESP-AT UART driver. Supports single connection, +IPD active receive.
Target: Espressif ESP8266 ESP-AT 2.2.0.0 command set, not verified on user's module.
All UART waits yield: local reminders keep running during network outages.
"""
import time
import uasyncio as asyncio
class ESPAT:
    def __init__(self,uart): self.uart=uart; self.buffer=b''; self.connected=False
    async def wait(self,token,timeout=5000):
        start=time.ticks_ms()
        while time.ticks_diff(time.ticks_ms(),start)<timeout:
            if self.uart.any(): self.buffer+=self.uart.read() or b''
            if len(self.buffer)>24576: raise OSError('AT buffer overflow')
            if token in self.buffer:
                at=self.buffer.index(token)+len(token); result=self.buffer[:at]; self.buffer=self.buffer[at:]; return result
            if b'ERROR' in self.buffer or b'FAIL' in self.buffer: raise OSError('AT command failed')
            await asyncio.sleep_ms(10)
        raise OSError('AT timeout')
    async def at(self,command,token=b'OK',timeout=5000):
        self.buffer=b''
        while self.uart.any(): self.uart.read()
        self.uart.write(command+'\r\n'); return await self.wait(token,timeout)
    @staticmethod
    def quote(s):
        if any(c in s for c in ('\r','\n','\x00')): raise ValueError('Invalid AT string')
        return s.replace('\\','\\\\').replace('"','\\"').replace(',','\\,')
    async def connect(self,ssid,password):
        self.connected=False
        await self.at('AT'); await self.at('ATE0'); await self.at('AT+CWMODE=1')
        await self.at('AT+CWJAP="%s","%s"'%(self.quote(ssid),self.quote(password)),timeout=20000)
        await self.at('AT+CIPMUX=0'); await self.at('AT+CIPRECVMODE=0')
        try: await self.at('AT+CIPCLOSE',timeout=1000)
        except OSError: self.buffer=b''
        self.connected=True
    async def request(self,host,port,payload):
        parts=host.split('.')
        if len(parts)!=4 or not all(p.isdigit() and 0<=int(p)<=255 for p in parts): raise ValueError('Use a LAN IPv4 address')
        await self.at('AT+CIPSTART="TCP","%s",%d'%(host,port),timeout=10000)
        self.buffer=b''
        for offset in range(0,len(payload),1024):
            chunk=payload[offset:offset+1024]
            self.uart.write('AT+CIPSEND=%d\r\n'%len(chunk)); await self.wait(b'>')
            self.uart.write(chunk)
            # Preserve bytes arriving immediately after SEND OK.
            await self.wait(b'SEND OK',10000)
        data=b''; start=time.ticks_ms()
        try:
            while time.ticks_diff(time.ticks_ms(),start)<15000:
                if self.uart.any(): self.buffer+=self.uart.read() or b''
                while b'+IPD,' in self.buffer:
                    pos=self.buffer.index(b'+IPD,'); colon=self.buffer.find(b':',pos)
                    if colon<0: break
                    count=int(self.buffer[pos+5:colon])
                    if not 0<=count<=16384: raise OSError('Invalid frame size')
                    end=colon+1+count
                    if len(self.buffer)<end: break
                    data+=self.buffer[colon+1:end]; self.buffer=self.buffer[end:]
                if len(data)>16384 or len(self.buffer)>24576: raise OSError('Response too big')
                if b'\r\n\r\n' in data:
                    head,body=data.split(b'\r\n\r\n',1)
                    length=None
                    for line in head.split(b'\r\n')[1:]:
                        if line.lower().startswith(b'content-length:'): length=int(line.split(b':',1)[1])
                    if length is not None and not 0<=length<=16384: raise OSError('Invalid response length')
                    if length is not None and len(body)>=length:
                        if not head.startswith(b'HTTP/1.0 200') and not head.startswith(b'HTTP/1.1 200'): raise OSError('Server rejected request')
                        return body[:length]
                if b'CLOSED' in self.buffer: raise OSError('Truncated response')
                await asyncio.sleep_ms(10)
            raise OSError('HTTP timeout')
        finally:
            try: await self.at('AT+CIPCLOSE',timeout=1000)
            except OSError: self.connected=False

    def close(self):
        self.connected=False
        self.buffer=b''
        self.uart.deinit()
