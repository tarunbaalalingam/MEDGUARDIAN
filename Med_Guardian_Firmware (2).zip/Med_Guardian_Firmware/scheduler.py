import time
from protocol import schedule
class Scheduler:
    def __init__(self,values,offset=330): self.values=schedule(values); self.offset=offset
    def current(self,now):
        t=time.gmtime(now+self.offset*60)
        date='%04d-%02d-%02d'%t[:3]; minute=t[3]*60+t[4]
        found=[]
        for slot,when in self.values.items():
            if when is not None:
                due=int(when[:2])*60+int(when[3:])
                # Never catch up an old dose; 15 minute request window.
                if 0<=minute-due<15: found.append(date+':'+slot)
        return found
    def reminder(self,now,journal):
        for occurrence in self.current(now):
            if not journal.seen('reminder',occurrence): journal.append('reminder',occurrence,now)
    def ringing(self,now,journal):
        for occ in self.current(now):
            if journal.claimed(occ): continue
            snoozes=[e['at'] for e in journal.events if e['kind']=='snoozed' and e['occurrence']==occ]
            if not snoozes or now>=max(snoozes)+300: return True
        return False
    def snooze(self,occ,now,journal):
        if occ not in self.current(now): raise ValueError('No current reminder')
        journal.append('snoozed',occ,now,'Reminder muted for five minutes; no motion')
