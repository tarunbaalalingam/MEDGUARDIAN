"""Channel A gain 128; bounded reads, signed raw counts, no boot tare."""
import machine
import time
import uasyncio as asyncio

class HX711:
    def __init__(self, data, clock, timeout_ms=1000):
        self.data = machine.Pin(data, machine.Pin.IN)
        self.clock = machine.Pin(clock, machine.Pin.OUT, value=0)
        self.timeout_ms = timeout_ms
        self.last_read_ms = None
        # Recover known gain/channel after a soft reset; next conversion is fresh.
        self.clock.value(1)
        time.sleep_us(80)
        self.clock.value(0)

    async def raw(self):
        start = time.ticks_ms()
        while self.data.value():
            if time.ticks_diff(time.ticks_ms(), start) >= self.timeout_ms:
                raise OSError('HX711 timeout')
            await asyncio.sleep_ms(5)
        value = 0
        irq = machine.disable_irq()
        try:
            for _ in range(24):
                self.clock.value(1)
                time.sleep_us(1)
                bit = self.data.value()
                self.clock.value(0)
                value = (value << 1) | bit
                # 1 us low time produced all-ones reads on this Pico.
                time.sleep_us(5)
            self.clock.value(1)
            time.sleep_us(1)
            self.clock.value(0)
        finally:
            self.clock.value(0)
            machine.enable_irq(irq)
        value = value - 16777216 if value & 8388608 else value
        if value in (-8388608, 8388607):
            raise OSError('HX711 saturation')
        self.last_read_ms = time.ticks_ms()
        return value

    async def samples(self, n=5):
        if type(n) is not int or not 1 <= n <= 32:
            raise ValueError('Sample count must be 1..32')
        # A ready conversion can predate this batch (e.g. before servo motion).
        # Discard it, then collect conversions initiated after the request.
        await self.raw()
        values = []
        for _ in range(n):
            values.append(await self.raw())
        return values

    async def tare(self, n=10):
        """Return offset; caller deliberately saves LOAD_OFFSET."""
        raw = await self.samples(n)
        return sum(raw) / len(raw)

    async def calibrate(self, offset, known_grams, n=10):
        """Return signed counts/gram for a known inert mass after tare."""
        from safety_manager import finite
        if not finite(offset) or not finite(known_grams) or known_grams <= 0:
            raise ValueError('Invalid calibration input')
        scale = (await self.tare(n) - offset) / known_grams
        if not finite(scale) or scale == 0:
            raise ValueError('No usable load change')
        return scale
