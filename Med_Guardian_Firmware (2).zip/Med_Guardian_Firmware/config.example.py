# Copy to config.py, migrate existing values locally; never commit credentials.
DEVICE_ID = 'nestiq-01'
DEVICE_KEY = ''
SSID = ''
WIFI_PASSWORD = ''
SERVER_HOST = ''
SERVER_PORT = 8080
ALLOW_LAN_HTTP = False  # Existing signed HTTP protocol; isolated trusted LAN.
NETWORK_ENABLED = True
NETWORK_TRANSPORT = 'esp_at'  # Preserve supplied architecture, not native CYW43.
ESP_BAUD = 115200
WIRING_VERIFIED = False
ACTUATION_VERIFIED = False
CALIBRATED = False
USB_TIME_SYNC_ENABLED = True  # Accept trusted UTC epoch from USB ("TIME,<epoch>").

# Nominal endpoints only: measure pulse ranges and mechanical limits separately.
# Adjacent servos share RP2040 PWM slices and MUST use the same frequency.
SERVOS = {
    1: dict(role='portable_flap', min_us=1000, max_us=2000, frequency=50,
            travel_deg=180, min_angle=0, max_angle=180, calibrated=False),
    2: dict(role='daily_rotation', min_us=1000, max_us=2000, frequency=50,
            travel_deg=180, min_angle=0, max_angle=180, calibrated=False),
    3: dict(role='storage_rotation', min_us=1000, max_us=2000, frequency=50,
            travel_deg=360, min_angle=0, max_angle=360, calibrated=False),
    4: dict(role='dock_flap', min_us=1000, max_us=2000, frequency=50,
            travel_deg=180, min_angle=0, max_angle=180, calibrated=False),
}
SERVO3_POSITION_MODE_CONFIRMED = True  # User confirmed positional 360-degree unit.
STORAGE_ANGLES = (0, 72, 144, 216, 288)  # Positions 1..5, no wrapping across 360.
PORTABLE_OPEN_ANGLE = None
PORTABLE_CLOSED_ANGLE = None
DOCK_OPEN_ANGLE = None
DOCK_CLOSED_ANGLE = None
# Servo 4 supports local supervised diagnostics only. Portable dispensing never
# uses a dock or Servo 4. This switch enables ONLY the local diagnostic API.
DOCK_DIAGNOSTICS_ENABLED = False

# Preserve schedule slot names, but do not equate slot names with servo roles.
# New sequences can coordinate multiple servos with dictionaries:
# {'servo': 3, 'position': 2, 'dwell_ms': measured_ms}
# {'servo': 1, 'angle': measured_angle, 'dwell_ms': measured_ms}
# End with a mechanically safe return path. No release path is invented here.
SERVO_SEQUENCES = {'morning': [], 'afternoon': [], 'night': []}
# For migration only: legacy [(pulse_us, dwell_ms), ...] uses this slot->ID map.
SERVO_ROLE_MAP = {}
WEIGHT_SETTLE_MS = 500  # Commission with actual settling time.

LIMIT_SWITCH_ACTIVE = 0  # COM -> GND, NO -> GP16, internal pull-up.
LIMIT_DEBOUNCE_MS = 50
LIMIT_SWITCH_ROLE = 'docked'  # User confirmed: activated while attached to dock.
DOCK_SENSOR_REQUIRED = True
LID_INTERLOCK_REQUIRED = True  # Preserved required safety check; do not bypass.
# These sensors existed in the supplied project; disable only after reviewing
# their safety role. Required disabled sensors block dispensing, not startup.
HC_SR04_ENABLED = True
HC_SR04_ECHO_3V3_SAFE = False  # Require confirmed divider/level shifter before ECHO reads.
MPU6050_ENABLED = True
BUZZER_ENABLED = False  # Fit and test a buzzer before enabling audible alerts.
CUP_SENSOR_REQUIRED = True
MOTION_SENSOR_REQUIRED = True
LOAD_OFFSET = None
LOAD_SCALE = None  # signed counts/gram, nonzero
STABILITY_G = None
EMPTY_CUP_G = None
EMPTY_CUP_TOLERANCE_G = None
EXPECTED_DELTA_G = {'morning': None, 'afternoon': None, 'night': None}
DELTA_TOLERANCE_G = None
CUP_DISTANCE_CM = None  # measured (minimum, maximum)
MAX_TILT_DEG = 10
MAX_MOTION_G = 0.10
HX_TIMEOUT_MS = 1000
SENSOR_MAX_AGE_MS = 2000
GPS_ENABLED = True
GPS_BAUD = 9600  # Preserves supplied default; confirm on the actual receiver.
GPS_STALE_MS = 5000
TIMEZONE_MINUTES = 330
MAX_CLOCK_AGE_S = 86400
# Schedules remain reminders only; dispensing requires a current app command.
