import uasyncio as asyncio
import json
from machine import UART, Pin
import pins
from configuration import validate
from event_logger import Journal, save_json
from scheduler import Scheduler
from clock import Clock
from buzzer import Buzzer
from servo_controller import Servo
from sensors import Sensors
from dispenser import Dispenser
from wifi_manager import ESPAT
from communications import Communications
from protocol import schedule
import daily_auto
import usb_clock


async def run():
    import config as c
    validate(c)
    if not c.WIRING_VERIFIED:
        print('Commissioning lock: verify wiring/config.py. No GPIO initialized.')
        return
    journal = Journal()
    clock = Clock(c.MAX_CLOCK_AGE_S)
    values = dict(morning=None, afternoon=None, night=None)
    try:
        with open('schedule.json') as f:
            values = schedule(json.load(f))
    except OSError as e:
        if e.args and e.args[0] == 2:
            print('No cached schedule')
        else:
            journal.fault = 'Schedule storage unavailable'
    except (ValueError, TypeError):
        journal.fault = 'Corrupt schedule'
    scheduler = Scheduler(values, c.TIMEZONE_MINUTES)
    print('Commissioning: wiring=%s calibration=%s actuation=%s' %
          (c.WIRING_VERIFIED, c.CALIBRATED, c.ACTUATION_VERIFIED))
    print('Buzzer: %s; USB time sync: %s; network: %s' %
          (c.BUZZER_ENABLED, c.USB_TIME_SYNC_ENABLED, c.NETWORK_ENABLED))
    servo = sensors = buzzer = transport = None
    tasks = []
    active = [None]
    try:
        servo = Servo(c)
        sensors = Sensors(c)
        if c.BUZZER_ENABLED:
            buzzer = Buzzer(pins.BUZZER)
        dispenser = Dispenser(c, journal, scheduler, sensors, servo, clock)
        state = {'network': 'offline' if c.NETWORK_ENABLED else 'disabled',
                 'last_error': None}
        ack = 0
        comm = None
        if c.NETWORK_ENABLED:
            transport = ESPAT(UART(0, c.ESP_BAUD, tx=Pin(pins.ESP_TX),
                                  rx=Pin(pins.ESP_RX), rxbuf=8192, timeout=0))
            comm = Communications(c, transport)

        async def guarded(name, factory):
            # A closed USB host port must not end standalone reminders.
            while True:
                try:
                    await factory()
                except asyncio.CancelledError:
                    raise
                except KeyboardInterrupt:
                    raise
                except BaseException as exc:
                    try:
                        print('Task', name, 'failed:', type(exc).__name__,
                              '- restarting')
                    except Exception:
                        pass
                    await asyncio.sleep_ms(1000)

        async def local():
            elapsed = 0
            while True:
                try:
                    sensors.poll()
                    elapsed += 20
                    if elapsed >= 250:
                        elapsed = 0
                        if clock.trusted():
                            scheduler.reminder(clock.now(), journal)
                            if buzzer and scheduler.ringing(clock.now(), journal):
                                await buzzer.chirp()
                except Exception as e:
                    state['last_error'] = 'Local monitoring failed: ' + type(e).__name__
                await asyncio.sleep_ms(20)

        async def dispatch(commands):
            try:
                for cmd in commands:
                    await dispenser.execute(cmd)
            except Exception as e:
                state['last_error'] = 'Command failed: ' + type(e).__name__
            finally:
                active[0] = None

        async def network():
            nonlocal ack
            while True:
                try:
                    s = await sensors.snapshot()
                    s.update(clock_trusted=clock.trusted(), network=state['network'],
                             last_error=state['last_error'],
                             actuation_verified=c.ACTUATION_VERIFIED,
                             calibrated=c.CALIBRATED,
                             current_occurrences=scheduler.current(clock.now()) if clock.trusted() else [],
                             dock_control='disabled: portable design',
                             journal_fault=journal.fault,
                             dispensing_state=dispenser.state,
                             dispensing_error=dispenser.last_error)
                    data = await comm.exchange(s, journal.pending(ack))
                    if not ack <= data['ack_seq'] <= journal.seq:
                        raise ValueError('Server journal acknowledgement mismatch')
                    clock.sync(data['server_time'])
                    values = schedule(data['schedule'])
                    if values != scheduler.values:
                        save_json('schedule.json', values)
                        scheduler.values = values
                    ack = data['ack_seq']
                    state['network'] = 'online'
                    state['last_error'] = None
                    if data['commands'] and active[0] is None:
                        active[0] = asyncio.create_task(dispatch(data['commands']))
                except Exception as e:
                    state['network'] = 'offline'
                    state['last_error'] = 'Exchange failed: ' + type(e).__name__
                    transport.connected = False
                await asyncio.sleep(5 if state['network'] == 'online' else 15)

        tasks.append(asyncio.create_task(guarded('local', local)))
        tasks.append(asyncio.create_task(guarded(
            'daily', lambda: daily_auto.run_daily(clock, c.TIMEZONE_MINUTES))))
        if c.USB_TIME_SYNC_ENABLED:
            tasks.append(asyncio.create_task(guarded(
                'usb_clock', lambda: usb_clock.run(clock))))
        if comm:
            tasks.append(asyncio.create_task(guarded('network', network)))
        print('Med Guardian ready; PWM idle. Local reminders run without the dashboard.')
        print('Dispensing stays blocked until calibration and actuation are verified.')
        await asyncio.gather(*tasks)
    finally:
        try:
            if servo:
                servo.stop()
        finally:
            if active[0] is not None:
                tasks.append(active[0])
            for task in tasks:
                task.cancel()
            for task in tasks:
                try:
                    await task
                except asyncio.CancelledError:
                    pass
                except Exception as e:
                    print('Task shutdown error:', type(e).__name__)
            for resource in (sensors, buzzer, transport):
                if resource:
                    try:
                        resource.close()
                    except Exception as e:
                        print('Resource shutdown error:', type(e).__name__)


if __name__ == '__main__':
    try:
        asyncio.run(run())
    except KeyboardInterrupt:
        print('Stopped; PWM released.')
    except Exception as e:
        print('Startup/runtime stopped:', type(e).__name__,
              'Check config.py and commissioning diagnostics.')
