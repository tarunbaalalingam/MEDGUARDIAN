"""Bounded checksum-valid NMEA ingestion; RMC fix state kept separately."""
import time
import math

def nmea_fields(line):
    try:
        if len(line) > 256:
            return None
        body, checksum = line.strip().split('*')
        if not body.startswith('$') or len(checksum) != 2:
            return None
        xor = 0
        for c in body[1:]:
            xor ^= ord(c)
        if xor != int(checksum, 16):
            return None
        fields = body[1:].split(',')
        if len(fields[0]) != 5 or not fields[0].isalpha():
            return None
        return fields
    except (ValueError, TypeError):
        return None

def parse_rmc(line):
    p = nmea_fields(line)
    try:
        if p is None or p[0] not in ('GPRMC','GNRMC') or p[2] != 'A':
            return None
        if p[4] not in ('N','S') or p[6] not in ('E','W'):
            return None
        if len(p) > 12 and p[12] == 'N':
            return None
        utc = p[1].split('.')
        if len(utc) > 2 or len(utc[0]) != 6 or not utc[0].isdigit() or (len(utc) == 2 and not utc[1].isdigit()):
            return None
        if int(utc[0][:2]) > 23 or int(utc[0][2:4]) > 59 or int(utc[0][4:]) > 60:
            return None
        def degrees(v, hemisphere, digits, maximum):
            if len(v) < digits+2 or not v[:digits].isdigit():
                raise ValueError('Invalid degrees')
            minutes = float(v[digits:])
            d = int(v[:digits])
            if not math.isfinite(minutes) or not 0 <= minutes < 60 or d > maximum or (d == maximum and minutes != 0):
                raise ValueError('Invalid minutes')
            result = d + minutes/60
            return -result if hemisphere in ('S','W') else result
        return dict(latitude=degrees(p[3],p[4],2,90),
                    longitude=degrees(p[5],p[6],3,180), utc=p[1])
    except (ValueError, IndexError, TypeError):
        return None

class GPS:
    def __init__(self, uart, stale_ms=5000):
        self.uart = uart
        self.buffer = b''
        self.stale_ms = stale_ms
        self.last_sentence_ms = None
        self.last_fix_ms = None
        self.fix = None
        self.malformed = 0

    def poll(self):
        if self.uart.any():
            self.buffer += self.uart.read(512) or b''
        while b'\n' in self.buffer:
            line, self.buffer = self.buffer.split(b'\n', 1)
            try:
                text = line.decode('ascii')
                fields = nmea_fields(text)
            except UnicodeError:
                fields = None
            if fields is None:
                self.malformed += 1
                continue
            self.last_sentence_ms = time.ticks_ms()
            if fields[0] in ('GPRMC','GNRMC'):
                self.fix = parse_rmc(text)  # A later no-fix RMC clears old location.
                self.last_fix_ms = time.ticks_ms() if self.fix else None
        if len(self.buffer) > 256:
            self.buffer = b''
            self.malformed += 1
        return self.location()

    def location(self):
        if self.last_fix_ms is None or time.ticks_diff(time.ticks_ms(), self.last_fix_ms) > self.stale_ms:
            return None
        return self.fix

    def status(self):
        now = time.ticks_ms()
        nmea = self.last_sentence_ms is not None and time.ticks_diff(now,self.last_sentence_ms) <= self.stale_ms
        return dict(nmea_received=nmea, fix_valid=self.location() is not None,
                    state='fix' if self.location() else ('no_fix' if nmea else 'unavailable'),
                    malformed=self.malformed)

    def close(self):
        self.uart.deinit()
