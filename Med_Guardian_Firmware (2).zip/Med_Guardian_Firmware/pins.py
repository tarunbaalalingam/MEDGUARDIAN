"""Central GPIO map for Med Guardian portable unit. GPIO numbers, not header numbers."""
ESP_TX=0; ESP_RX=1  # Existing ESP-AT transport on UART0
HX_DATA=2; HX_CLOCK=3
ULTRA_TRIG=4; ULTRA_ECHO=5  # Optional existing HC-SR04
MPU_SDA=6; MPU_SCL=7       # Optional existing MPU6050
GPS_UART_TX=8; GPS_UART_RX=9  # Pico TX to GPS RX; GPS TX to Pico RX
BUZZER=14                  # Optional existing buzzer
LIMIT_SWITCH=16
SERVO_1=18
SERVO_2=19
SERVO_3=20
SERVO_4=21
SERVO_PINS=(SERVO_1,SERVO_2,SERVO_3,SERVO_4)
SERVO_ROLES={
    1: 'portable_flap_open',
    2: 'daily_compartment_rotation',
    3: 'storage_rotation_360_positional',
    4: 'dock_flap_open_future_docking_disabled',
}
def validate():
    # UART/I2C/optional sensors and servos must not overlap.
    groups={
        'ESP UART':(ESP_TX,ESP_RX), 'HX711':(HX_DATA,HX_CLOCK),
        'HC-SR04':(ULTRA_TRIG,ULTRA_ECHO), 'MPU6050':(MPU_SDA,MPU_SCL),
        'GPS UART':(GPS_UART_TX,GPS_UART_RX), 'buzzer':(BUZZER,),
        'limit switch':(LIMIT_SWITCH,), 'servos':SERVO_PINS,
    }
    used={}
    for group,pins in groups.items():
        for pin in pins:
            if pin in used: raise ValueError('GPIO conflict: GP%d used by %s and %s'%(pin,used[pin],group))
            used[pin]=group

PHYSICAL_PINS={0:1,1:2,2:4,3:5,4:6,5:7,6:9,7:10,8:11,9:12,14:19,16:21,18:24,19:25,20:26,21:27}
