import json
import os
import binascii
from protocol import mac,equal,schedule,command
class Communications:
    def __init__(self,cfg,transport): self.cfg=cfg; self.transport=transport
    async def exchange(self,telemetry,events):
        c=self.cfg
        if not c.ALLOW_LAN_HTTP or len(c.DEVICE_KEY)!=64: raise ValueError('Network configuration incomplete')
        nonce=binascii.hexlify(os.urandom(16)).decode()
        inner=json.dumps(dict(v=1,device_id=c.DEVICE_ID,nonce=nonce,telemetry=telemetry,events=events))
        envelope=json.dumps(dict(payload=inner,signature=mac(c.DEVICE_KEY,inner.encode()))).encode()
        request=('POST /api/v1/device/exchange HTTP/1.0\r\nHost: %s\r\nContent-Type: application/json\r\nContent-Length: %d\r\nConnection: close\r\n\r\n'%(c.SERVER_HOST,len(envelope))).encode()+envelope
        try:
            if not self.transport.connected: await self.transport.connect(c.SSID,c.WIFI_PASSWORD)
            response=json.loads(await self.transport.request(c.SERVER_HOST,c.SERVER_PORT,request))
            if not isinstance(response,dict) or set(response)!= {'payload','signature'}:
                raise ValueError('Invalid response envelope')
            if not isinstance(response['payload'],str) or not isinstance(response['signature'],str):
                raise ValueError('Invalid response fields')
            if not equal(mac(c.DEVICE_KEY,response['payload'].encode()),response['signature']): raise ValueError('Bad server signature')
            data=json.loads(response['payload'])
            if not isinstance(data,dict) or data.get('nonce')!=nonce or data.get('v')!=1: raise ValueError('Stale server response')
            if type(data.get('server_time')) is not int or data['server_time']<1700000000:
                raise ValueError('Invalid server time')
            if type(data.get('ack_seq')) is not int or data['ack_seq']<0:
                raise ValueError('Invalid acknowledgement')
            schedule(data['schedule'])
            if not isinstance(data.get('commands'),list) or len(data['commands'])>6:
                raise ValueError('Invalid command batch')
            for cmd in data['commands']: command(cmd)
            return data
        except BaseException:
            self.transport.connected=False
            raise
