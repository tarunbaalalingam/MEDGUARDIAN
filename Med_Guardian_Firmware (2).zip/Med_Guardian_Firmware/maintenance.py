"""Local USB technician tool only; never exposed over the network."""
from event_logger import Journal

def reconcile(occurrence,epoch,note,physical_checked=False):
    import config
    if config.ACTUATION_VERIFIED: raise RuntimeError('Disable actuation in config and isolate motor power first')
    if not physical_checked or not isinstance(note,str) or len(note)<12: raise ValueError('Physical inspection and explanation required')
    if type(epoch)!=int or epoch<1700000000: raise ValueError('Provide current Unix time')
    j=Journal()
    if not j.claimed(occurrence): raise ValueError('No attempt to reconcile')
    j.append('reconciled',occurrence,epoch,'Local technician: '+note)
    print('Reconciled for FUTURE occurrences. Existing attempt remains claimed.')
