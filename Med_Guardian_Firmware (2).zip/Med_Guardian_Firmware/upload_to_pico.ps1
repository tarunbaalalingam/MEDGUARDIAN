# upload_to_pico.ps1 — upload all firmware files to Pico COM5
# IMPORTANT: If main.py is running on the Pico, the serial port is busy.
#   Press the Pico's BOOTSEL button while plugging in USB, OR
#   run: py -3 -m mpremote connect COM5 soft-reset  (then wait 3 seconds)
# Run from: C:\Users\admin\Downloads\Med_Guardian_Firmware
# Usage: .\upload_to_pico.ps1

$ErrorActionPreference = "Stop"
$COM = "COM5"
$files = @(
    "config.py", "config.example.py", "pins.py", "configuration.py",
    "safety_manager.py", "sensors.py", "hx711.py", "mpu6050.py",
    "gps.py", "hcsr04.py", "limit_switch.py", "servo_controller.py",
    "scheduler.py", "dispenser.py", "clock.py", "usb_clock.py",
    "buzzer.py", "wifi_manager.py", "communications.py", "protocol.py",
    "event_logger.py", "daily_auto.py", "maintenance.py",
    "main.py", "sequential_test.py", "med_guardian.txt"
)

# First, try a soft reset to free the serial port
Write-Host "Resetting Pico on $COM ..." -ForegroundColor Yellow
try {
    py -3 -m mpremote connect $COM soft-reset 2>&1 | Out-Null
    Start-Sleep -Seconds 3
    Write-Host "  Reset OK" -ForegroundColor Green
} catch {
    Write-Host "  Reset failed — Pico may need manual BOOTSEL reset" -ForegroundColor Yellow
    Write-Host "  (Hold BOOTSEL while plugging in USB, then release)" -ForegroundColor Yellow
}

$failed = @()
$success = 0

foreach ($f in $files) {
    $path = Join-Path $PSScriptRoot $f
    if (-not (Test-Path $path)) {
        Write-Warning "File not found: $f — skipping"
        $failed += $f
        continue
    }
    Write-Host "Uploading $f ..." -ForegroundColor Cyan
    try {
        py -3 -m mpremote connect $COM fs cp $path ":$f" 2>&1 | Out-Null
        Write-Host "  OK" -ForegroundColor Green
        $success++
    } catch {
        Write-Host "  FAILED: $($_.Exception.Message)" -ForegroundColor Red
        $failed += $f
    }
}

Write-Host ""
Write-Host "Upload complete: $success succeeded, $($failed.Count) failed out of $($files.Count) files." -ForegroundColor White
if ($failed.Count -gt 0) {
    Write-Host "Failed files: $($failed -join ', ')" -ForegroundColor Red
}
