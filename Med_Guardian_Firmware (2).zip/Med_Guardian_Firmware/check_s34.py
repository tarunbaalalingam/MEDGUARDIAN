# Quick check of Servo 3 (GP20) and Servo 4 (GP21)
import config
from servo_controller import ServoBank
import time

print('=== SERVO 3 & 4 CHECK ===')
print()

# Servo 3: Selector (GP20) - continuous rotation
print('--- Servo 3: Selector (GP20) ---')
print('  Type: Continuous rotation servo')
bank = ServoBank(config)

# Try center/stop signal first
print('  Sending center/stop signal (1500us) ...')
bank.move_angle(3, 90)  # 90 deg = ~1500us center
time.sleep(2)
print('  ^ Did it stop or stay still?')

# Try left rotation
print('  Sending left rotation (1000us) ...')
bank.move_angle(3, 0)   # 0 deg = ~1000us
time.sleep(2)
print('  ^ Did it spin left?')

# Try right rotation
print('  Sending right rotation (2000us) ...')
bank.move_angle(3, 180) # 180 deg = ~2000us
time.sleep(2)
print('  ^ Did it spin right?')

# Stop
bank.stop()
time.sleep(1)
print('  Stopped')
print()

# Servo 4: Dock flap (GP21)
print('--- Servo 4: Dock flap (GP21) ---')
print('  Diagnostics enabled:', config.DOCK_DIAGNOSTICS_ENABLED)
bank = ServoBank(config)

print('  Closed (0 deg) ...')
bank.move_angle(4, 0)
time.sleep(1.5)
print('  ^ Flap should be closed')

print('  Opened (90 deg) ...')
bank.move_angle(4, 90)
time.sleep(1.5)
print('  ^ Flap should be open')

print('  Closed (0 deg) ...')
bank.move_angle(4, 0)
time.sleep(1.5)
print('  ^ Flap should be closed')

bank.stop()
print()
print('=== TEST COMPLETE ===')
print()
print('Tell me:')
print('  Servo 3: Did it spin left, spin right, or not move?')
print('  Servo 4: Did the flap open and close?')
