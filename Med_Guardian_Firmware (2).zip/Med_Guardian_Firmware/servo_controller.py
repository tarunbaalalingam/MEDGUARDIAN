"""Independent positional channels with cooperative dwell and no boot movement."""
from machine import Pin, PWM
import uasyncio as asyncio
import pins
from configuration import validate
from safety_manager import finite

class ServoBank:
    def __init__(self, cfg):
        validate(cfg)  # Pure validation; constructing a bank creates no GPIO/PWM.
        self.cfg = cfg
        self.pwms = {}
        self.commanded = {}
        self.busy = False

    def settings(self, sid):
        if type(sid) is not int or sid not in self.cfg.SERVOS:
            raise ValueError('Servo ID must be 1..4')
        return self.cfg.SERVOS[sid]

    def angle_to_us(self, sid, angle, clamp=False):
        s = self.settings(sid)
        if not finite(angle):
            raise ValueError('Angle must be finite')
        if clamp:
            angle = max(s['min_angle'], min(s['max_angle'], angle))
        if not s['min_angle'] <= angle <= s['max_angle']:
            raise ValueError('Angle outside configured mechanical range')
        return round(s['min_us'] + angle / s['travel_deg'] * (s['max_us'] - s['min_us']))

    def storage_angle(self, position):
        if type(position) is not int or not 1 <= position <= 5:
            raise ValueError('Storage position must be 1..5')
        return self.cfg.STORAGE_ANGLES[position-1]

    def _check_enabled(self, sid, production=False):
        s = self.settings(sid)
        if not self.cfg.WIRING_VERIFIED or not s['calibrated']:
            raise ValueError('Wiring and this servo calibration must be verified')
        if sid == 4 and (production or not self.cfg.DOCK_DIAGNOSTICS_ENABLED):
            raise ValueError('Dock servo disabled for portable dispensing')

    def _write(self, sid, pulse):
        s = self.settings(sid)
        low = self.angle_to_us(sid, s['min_angle'])
        high = self.angle_to_us(sid, s['max_angle'])
        if not finite(pulse) or not low <= pulse <= high:
            raise ValueError('Pulse outside configured mechanical range')
        if sid not in self.pwms:
            self.pwms[sid] = PWM(Pin(pins.SERVO_PINS[sid-1]),
                                 freq=int(s['frequency']), duty_u16=0)
        self.pwms[sid].duty_ns(round(pulse * 1000))
        # Command only. No positional feedback is available.
        self.commanded[sid] = pulse

    def move_angle(self, sid, angle, clamp=False):
        if self.busy:
            raise RuntimeError('Dispense sequence owns the servos')
        self._check_enabled(sid)
        pulse = self.angle_to_us(sid, angle, clamp)
        try:
            self._write(sid, pulse)
        except BaseException:
            self.stop()
            raise

    def storage_position(self, position):
        self.move_angle(3, self.storage_angle(position))

    def daily_rotate(self, angle):
        self.move_angle(2, angle)

    def portable_open(self):
        self.move_angle(1, self.cfg.PORTABLE_OPEN_ANGLE)

    def portable_close(self):
        self.move_angle(1, self.cfg.PORTABLE_CLOSED_ANGLE)

    def dock_open(self):
        self.move_angle(4, self.cfg.DOCK_OPEN_ANGLE)

    def dock_close(self):
        self.move_angle(4, self.cfg.DOCK_CLOSED_ANGLE)

    def _plan(self, slot):
        seq = self.cfg.SERVO_SEQUENCES.get(slot, ())
        if not self.cfg.ACTUATION_VERIFIED or not 2 <= len(seq) <= 12:
            raise ValueError('Release path not verified')
        result = []
        for step in seq:
            if isinstance(step, dict):
                sid = step.get('servo')
                if set(step) == {'servo','position','dwell_ms'} and sid == 3:
                    angle = self.storage_angle(step['position'])
                elif set(step) == {'servo','angle','dwell_ms'}:
                    angle = step['angle']
                else:
                    raise ValueError('Invalid servo sequence step')
                pulse = self.angle_to_us(sid, angle)
                delay = step['dwell_ms']
            else:
                sid = self.cfg.SERVO_ROLE_MAP.get(slot)
                pulse, delay = step  # Preserve legacy pulse-sequence format.
            self._check_enabled(sid, production=True)
            s = self.settings(sid)
            if not finite(pulse) or not self.angle_to_us(sid,s['min_angle']) <= pulse <= self.angle_to_us(sid,s['max_angle']):
                raise ValueError('Sequence pulse outside mechanical range')
            if type(delay) is not int or not 50 <= delay <= 3000:
                raise ValueError('Invalid dwell')
            result.append((sid, pulse, delay))
        if sum(step[2] for step in result) > 15000:
            raise ValueError('Sequence too long')
        return result

    def validate(self, slot):
        return self._plan(slot)

    async def release(self, slot, guard):
        if self.busy:
            raise RuntimeError('Servo sequence already active')
        plan = self._plan(slot)  # Validate entire path before first pulse.
        self.busy = True
        try:
            for sid, pulse, delay in plan:
                if not await guard():
                    raise RuntimeError('Interlock changed')
                self._write(sid, pulse)
                while delay:
                    step = min(20, delay)
                    await asyncio.sleep_ms(step)
                    delay -= step
                    if not await guard():
                        raise RuntimeError('Interlock changed')
        finally:
            self.busy = False
            self.stop()

    def stop_one(self, sid):
        # RP2040 deinit stops BOTH channels on a slice. Zero just this channel.
        pwm = self.pwms.get(sid)
        if pwm is not None:
            pwm.duty_u16(0)
        self.commanded.pop(sid, None)

    def stop(self):
        # Zero every channel before deinitializing shared slices.
        first_error = None
        for pwm in tuple(self.pwms.values()):
            try:
                pwm.duty_u16(0)
            except Exception as e:
                first_error = first_error or e
        for pwm in tuple(self.pwms.values()):
            try:
                pwm.deinit()
            except Exception as e:
                first_error = first_error or e
        self.pwms.clear()
        self.commanded.clear()
        if first_error:
            raise first_error

Servo = ServoBank  # Existing integrated firmware import remains valid.
