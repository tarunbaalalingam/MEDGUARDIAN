from machine import Pin, I2C, UART
import time
import uasyncio as asyncio
import pins
from hx711 import HX711
from hcsr04 import HCSR04
from mpu6050 import MPU6050
from limit_switch import LimitSwitch
from gps import GPS
from safety_manager import finite, interlocks

class Sensors:
    def __init__(self, cfg):
        self.cfg = cfg
        self.hx = self.ultra = self.mpu = self.gps = self.limit_switch = None
        self.last_a = None
        self.init_faults = []
        self.lock = asyncio.Lock()
        try:
            self.hx = HX711(pins.HX_DATA,pins.HX_CLOCK,cfg.HX_TIMEOUT_MS)
        except Exception:
            self.init_faults.append('hx711_unavailable')
        try:
            self.limit_switch = LimitSwitch(pins.LIMIT_SWITCH,cfg.LIMIT_SWITCH_ACTIVE,cfg.LIMIT_DEBOUNCE_MS)
        except Exception:
            self.init_faults.append('limit_switch_unavailable')
        if cfg.HC_SR04_ENABLED:
            if getattr(cfg, 'HC_SR04_ECHO_3V3_SAFE', False):
                try:
                    self.ultra = HCSR04(pins.ULTRA_TRIG,pins.ULTRA_ECHO)
                except Exception:
                    self.init_faults.append('ultrasonic_unavailable')
            else:
                # Driving TRIG would energise a possibly 5 V ECHO output.
                self.init_faults.append('ultrasonic_echo_level_unconfirmed')
        if cfg.MPU6050_ENABLED:
            try:
                bus = I2C(1,sda=Pin(pins.MPU_SDA),scl=Pin(pins.MPU_SCL),freq=100000)
                baseline = None
                bx = getattr(cfg, 'MPU_BASELINE_X', None)
                by = getattr(cfg, 'MPU_BASELINE_Y', None)
                bz = getattr(cfg, 'MPU_BASELINE_Z', None)
                if bx is not None and by is not None and bz is not None:
                    baseline = (bx, by, bz)
                for address in (0x68, 0x69):
                    try:
                        self.mpu = MPU6050(bus, address, baseline=baseline)
                        break
                    except Exception:
                        self.mpu = None
            except Exception:
                self.mpu = None
            if self.mpu is None:
                self.init_faults.append('mpu6050_unavailable')
        self.gps_error = None
        if cfg.GPS_ENABLED:
            try:
                self.gps = GPS(UART(1,cfg.GPS_BAUD,tx=Pin(pins.GPS_UART_TX),
                                    rx=Pin(pins.GPS_UART_RX),rxbuf=2048,timeout=0),cfg.GPS_STALE_MS)
            except Exception:
                self.gps_error = 'GPS initialization failed'

    def poll(self):
        if self.limit_switch:
            self.limit_switch.update()
        if self.gps:
            try:
                self.gps.poll()
                self.gps_error = None
            except Exception:
                self.gps_error = 'GPS read failed'
                self.gps.fix = None
                self.gps.last_fix_ms = None

    def quick(self):
        c = self.cfg
        faults = list(self.init_faults)
        distance = tilt = motion = cup = None
        switch = self.limit_switch.state() if self.limit_switch else {'active':None,'ready':False}
        if self.ultra:
            try:
                distance = self.ultra.distance()
                if not finite(distance) or distance < 0:
                    raise ValueError('Invalid distance')
            except Exception:
                faults.append('ultrasonic')
        if self.mpu:
            try:
                tilt,motion,a = self.mpu.read()
                if self.last_a is not None:
                    motion = max(motion,sum((a[i]-self.last_a[i])**2 for i in range(3))**0.5)
                self.last_a = a
            except Exception:
                faults.append('mpu6050')
        if c.CUP_DISTANCE_CM is not None and distance is not None:
            cup = c.CUP_DISTANCE_CM[0] <= distance <= c.CUP_DISTANCE_CM[1]
        if c.CUP_SENSOR_REQUIRED and cup is None:
            faults.append('cup_sensor_unavailable_or_uncalibrated')
        if c.MOTION_SENSOR_REQUIRED and (tilt is None or motion is None):
            faults.append('motion_sensor_unavailable')
        lid = switch['active'] if c.LIMIT_SWITCH_ROLE == 'lid_closed' else None
        if c.LID_INTERLOCK_REQUIRED and lid is None:
            faults.append('lid_interlock_unassigned_or_unready')
        docked = switch['active'] if c.LIMIT_SWITCH_ROLE == 'docked' else None
        if c.DOCK_SENSOR_REQUIRED and docked is None:
            faults.append('dock_switch_unassigned_or_unready')
        return dict(cup_present=cup,distance_cm=distance,tilt_deg=tilt,motion_g=motion,
                    limit_switch=switch,lid_closed=lid,docked=docked,ir_beam=None,
                    faults=list(set(faults)))

    async def guard(self):
        return interlocks(self.cfg,self.quick()) is None

    async def snapshot(self):
        async with self.lock:  # Never interleave clock pulses from two callers.
            s = self.quick()
            s.update(weight_g=None,raw_counts=None,stable=False,weight_at_ms=None,gps=None)
            try:
                if self.hx is None:
                    raise OSError('HX711 unavailable')
                raw = await self.hx.samples()
                s['raw_counts'] = sum(raw)/len(raw)
                c = self.cfg
                if not finite(c.LOAD_OFFSET) or not finite(c.LOAD_SCALE) or c.LOAD_SCALE == 0 or not finite(c.STABILITY_G) or c.STABILITY_G < 0:
                    raise ValueError('Uncalibrated')
                g = [(r-c.LOAD_OFFSET)/c.LOAD_SCALE for r in raw]
                if not all(finite(v) for v in g):
                    raise ValueError('Invalid mass')
                s['weight_g'] = sum(g)/len(g)
                s['stable'] = max(g)-min(g) <= c.STABILITY_G
                s['weight_at_ms'] = self.hx.last_read_ms
            except Exception:
                s['faults'].append('hx711_or_calibration')
            fresh = self.quick()
            fresh['faults'] = list(set(s['faults']+fresh['faults']))
            s.update(fresh)
            s['gps'] = self.gps.location() if self.gps else None
            s['gps_status'] = self.gps.status() if self.gps else dict(state='unavailable' if self.cfg.GPS_ENABLED else 'disabled',fix_valid=False,nmea_received=False)
            s['gps_status']['error'] = self.gps_error
            return s

    def close(self):
        if self.hx:
            self.hx.clock.value(0)
        if self.gps:
            self.gps.close()
