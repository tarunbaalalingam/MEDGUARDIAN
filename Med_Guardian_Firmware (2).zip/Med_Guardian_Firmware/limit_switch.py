"""Debounced state/edge API; switch events never directly initiate dispensing."""
from machine import Pin
import time

class LimitSwitch:
    def __init__(self, pin, active=0, debounce_ms=50):
        self.pin = Pin(pin, Pin.IN, Pin.PULL_UP)
        self.active = active
        self.debounce_ms = debounce_ms
        self.raw = self.pin.value()
        self.changed = time.ticks_ms()
        self.stable = None  # Boot input must settle before being trusted.
        self.edge = None
        self.sequence = 0

    def update(self):
        value = self.pin.value()
        now = time.ticks_ms()
        if value != self.raw:
            self.raw = value
            self.changed = now
        if time.ticks_diff(now, self.changed) >= self.debounce_ms and self.stable != value:
            initial = self.stable is None
            self.stable = value
            if not initial:
                self.edge = 'activated' if value == self.active else 'released'
                self.sequence += 1
        return None if self.stable is None else self.stable == self.active

    def read(self):
        return self.update()

    def state(self):
        active = self.update()
        return dict(active=active, ready=self.stable is not None, raw=self.raw,
                    stable_level=self.stable, last_edge=self.edge, sequence=self.sequence)
