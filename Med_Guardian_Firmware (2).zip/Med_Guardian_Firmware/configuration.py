"""Structural validation before GPIO creation. Missing calibration stays locked."""
import pins
from safety_manager import finite

def validate(c):
    pins.validate()
    for k in ('WIRING_VERIFIED','ACTUATION_VERIFIED','CALIBRATED','NETWORK_ENABLED',
              'ALLOW_LAN_HTTP','SERVO3_POSITION_MODE_CONFIRMED','DOCK_DIAGNOSTICS_ENABLED',
              'LID_INTERLOCK_REQUIRED','DOCK_SENSOR_REQUIRED','CUP_SENSOR_REQUIRED',
              'MOTION_SENSOR_REQUIRED','HC_SR04_ENABLED','MPU6050_ENABLED',
              'BUZZER_ENABLED','GPS_ENABLED','USB_TIME_SYNC_ENABLED',
              'HC_SR04_ECHO_3V3_SAFE'):
        if type(getattr(c,k,None)) is not bool:
            raise ValueError('Configuration flag must be boolean: ' + k)
    if not hasattr(c, 'SERVOS'):
        raise ValueError('Migrate config.py using config.example.py: SERVOS missing')
    if set(c.SERVOS) != {1, 2, 3, 4}:
        raise ValueError('Exactly four servo configurations required')
    expected = ('portable_flap', 'daily_rotation', 'storage_rotation', 'dock_flap')
    for sid, s in c.SERVOS.items():
        if s.get('role') != expected[sid-1]:
            raise ValueError('Servo role mismatch')
        for k in ('min_us', 'max_us', 'frequency', 'travel_deg', 'min_angle', 'max_angle'):
            if not finite(s.get(k)):
                raise ValueError('Invalid servo parameter: ' + k)
        if not (400 <= s['min_us'] < s['max_us'] <= 2600 and
                40 <= s['frequency'] <= 60 and
                0 < s['travel_deg'] <= 360 and
                0 <= s['min_angle'] < s['max_angle'] <= s['travel_deg']):
            raise ValueError('Servo bounds invalid')
        if type(s.get('calibrated')) is not bool:
            raise ValueError('Servo calibrated must be boolean')
    for a, b in ((1, 2), (3, 4)):
        if c.SERVOS[a]['frequency'] != c.SERVOS[b]['frequency']:
            raise ValueError('Shared PWM slice requires matching frequencies')
    if tuple(c.STORAGE_ANGLES) != (0, 72, 144, 216, 288):
        raise ValueError('Storage requires five positions spaced 72 degrees')
    if c.SERVOS[3]['travel_deg'] != 360 or not c.SERVO3_POSITION_MODE_CONFIRMED:
        raise ValueError('Storage requires the confirmed 360-degree position servo')
    if c.LIMIT_SWITCH_ROLE not in ('unassigned', 'diagnostic', 'lid_closed', 'docked'):
        raise ValueError('Unknown limit-switch role; implement verified semantics first')
    if type(c.LIMIT_SWITCH_ACTIVE) is not int or c.LIMIT_SWITCH_ACTIVE not in (0, 1):
        raise ValueError('Invalid switch polarity')
    for k in ('LIMIT_DEBOUNCE_MS', 'HX_TIMEOUT_MS', 'SENSOR_MAX_AGE_MS', 'GPS_STALE_MS'):
        if type(getattr(c, k)) is not int or not 1 <= getattr(c, k) <= 60000:
            raise ValueError('Invalid timeout: ' + k)
    if type(c.WEIGHT_SETTLE_MS) is not int or not 0 <= c.WEIGHT_SETTLE_MS <= 10000:
        raise ValueError('Invalid settling delay')
    if c.NETWORK_TRANSPORT != 'esp_at':
        raise ValueError('This build uses the external ESP-AT module on UART0')
    if type(c.GPS_BAUD) is not int or c.GPS_BAUD <= 0:
        raise ValueError('Invalid GPS baud')
    if type(c.ESP_BAUD) is not int or c.ESP_BAUD <= 0:
        raise ValueError('Invalid ESP baud')
    if not isinstance(c.SERVO_SEQUENCES, dict) or set(c.SERVO_SEQUENCES) != {'morning','afternoon','night'}:
        raise ValueError('Servo sequences must use the existing three schedule slots')
    if c.LOAD_SCALE is not None and (not finite(c.LOAD_SCALE) or c.LOAD_SCALE == 0):
        raise ValueError('Invalid load scale')
    for k in ('LOAD_OFFSET', 'STABILITY_G', 'EMPTY_CUP_G', 'EMPTY_CUP_TOLERANCE_G',
              'DELTA_TOLERANCE_G', 'MAX_TILT_DEG', 'MAX_MOTION_G'):
        v = getattr(c, k)
        if v is not None and not finite(v):
            raise ValueError('Invalid calibration: ' + k)
    for k in ('STABILITY_G', 'EMPTY_CUP_TOLERANCE_G', 'DELTA_TOLERANCE_G', 'MAX_TILT_DEG', 'MAX_MOTION_G'):
        v = getattr(c, k)
        if v is not None and v < 0:
            raise ValueError('Negative calibration tolerance')
    window = c.CUP_DISTANCE_CM
    if window is not None and (not isinstance(window, (list, tuple)) or len(window) != 2 or
                              not all(finite(x) for x in window) or not 0 <= window[0] < window[1]):
        raise ValueError('Invalid cup distance window')
    if type(c.SERVER_PORT) is not int or not 1 <= c.SERVER_PORT <= 65535:
        raise ValueError('Invalid server port')
