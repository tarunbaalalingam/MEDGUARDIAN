# Quick test for Servo 3 (5-position selector on GP20)
import config
from servo_controller import ServoBank
import time

bank = ServoBank(config)
angles = config.STORAGE_ANGLES
print('Servo 3 angles:', angles)
print('WARNING: This is a continuous rotation servo')
print('It will NOT stop at specific angles')
print()

for i, angle in enumerate(angles, 1):
    print('>>> Position %d: %d deg — WATCH NOW <<<' % (i, angle))
    bank.move_angle(3, angle)
    time.sleep(3)
    print('  Stopping...')
    bank.stop()
    time.sleep(1)

print()
print('Done. Tell me: did it spin, jitter, or not move?')
