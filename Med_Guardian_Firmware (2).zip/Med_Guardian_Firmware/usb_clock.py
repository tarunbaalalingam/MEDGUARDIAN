"""Trusted clock source over USB CDC: each line is TIME,<utc_epoch>."""
import sys
import time
import uasyncio as asyncio
try:
    import select
except ImportError:
    import uselect as select

MAX_LINE = 64
MIN_EPOCH = 1700000000
MAX_EPOCH = 2147483647  # RP2040 gmtime is 32-bit signed time.


def parse_time_line(line):
    if isinstance(line, bytes):
        try:
            line = line.decode()
        except Exception:
            return None
    line = line.strip()
    if not line.startswith('TIME,'):
        return None
    value = line[5:]
    if not value.isdigit() or not 10 <= len(value) <= 11:
        return None
    epoch = int(value)
    if not MIN_EPOCH <= epoch <= MAX_EPOCH:
        return None
    return epoch


def _poller():
    poller = select.poll()
    poller.register(sys.stdin, select.POLLIN)
    return poller


def _read_char():
    try:
        value = sys.stdin.read(1)
    except Exception:
        return None
    if value is None or value == '':
        return None
    return value


def _report(epoch):
    stamp = time.gmtime(epoch)
    print('USB clock trusted: %04d-%02d-%02d %02d:%02d:%02dZ' % stamp[:6])


async def run(clock):
    poller = _poller()
    buffer = ''
    last_report = None
    last_error = None
    print('USB time sync: waiting for TIME,<utc_epoch> from the PC.')
    while True:
        try:
            if poller.poll(0):
                for _ in range(32):
                    char = _read_char()
                    if char is None:
                        break
                    if char in ('\r', '\n'):
                        epoch = parse_time_line(buffer)
                        buffer = ''
                        if epoch is not None:
                            try:
                                clock.sync(epoch)
                                if last_report is None or epoch - last_report >= 60:
                                    last_report = epoch
                                    _report(epoch)
                            except ValueError as exc:
                                if str(exc) != last_error:
                                    last_error = str(exc)
                                    print('USB time rejected:', exc)
                    elif len(buffer) < MAX_LINE:
                        buffer += char
                    else:
                        buffer = ''
        except Exception as exc:
            print('USB time reader error:', type(exc).__name__)
            await asyncio.sleep_ms(1000)
        await asyncio.sleep_ms(100)
