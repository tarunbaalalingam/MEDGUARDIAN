import json
import os

def flush_disk():
    if hasattr(os,'sync'): os.sync()

class Journal:
    """Append + readback before motion. Any corrupt line locks all motion."""
    def __init__(self,path='events.jsonl'):
        self.path=path; self.events=[]; self.seq=0; self.fault=None
        try:
            with open(path) as f:
                for line in f:
                    row=json.loads(line)
                    if row['seq'] != self.seq+1: raise ValueError('Journal gap')
                    self.events.append(row); self.seq=row['seq']
        except OSError as e:
            if getattr(e,'errno',e.args[0]) != 2: self.fault='Journal unavailable'
        except Exception: self.fault='Journal corrupt; manual reconciliation required'
    def append(self,kind,occurrence,at,detail=''):
        if self.fault: raise RuntimeError(self.fault)
        if self.seq>=128: raise RuntimeError('Journal full; archive/reconcile before reuse')
        row=dict(seq=self.seq+1,kind=kind,occurrence=occurrence,at=int(at),detail=str(detail)[:240])
        line=json.dumps(row)+'\n'
        try:
            with open(self.path,'a') as f: f.write(line); f.flush()
            flush_disk()
            last=None
            # Reopen and verify the final record is durable at the filesystem layer.
            with open(self.path) as f:
                for record in f: last=record
            if json.loads(last)!=row: raise OSError('Readback failed')
        except Exception:
            self.fault='Journal write failed'; raise
        self.events.append(row); self.seq+=1
        return row
    def claimed(self,occurrence):
        return any(e['occurrence']==occurrence and e['kind']=='attempt' for e in self.events)
    def seen(self,kind,occurrence):
        return any(e['occurrence']==occurrence and e['kind']==kind for e in self.events)
    def pending(self,ack): return [e for e in self.events if e['seq']>ack][:8]

def save_json(path,value):
    tmp=path+'.new'
    with open(tmp,'w') as f: json.dump(value,f); f.flush()
    flush_disk(); os.rename(tmp,path); flush_disk()
