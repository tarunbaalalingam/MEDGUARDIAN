from protocol import command
from safety_manager import preflight, verify_delta, finite, interlocks, weight_valid
import uasyncio as asyncio

class Dispenser:
    def __init__(self,cfg,journal,scheduler,sensors,servo,clock):
        self.cfg=cfg; self.journal=journal; self.scheduler=scheduler
        self.sensors=sensors; self.servo=servo; self.clock=clock
        self.busy=False
        self.state='idle'
        self.last_error=None

    async def execute(self,cmd):
        command(cmd)
        now=self.clock.now()
        occ=cmd['occurrence']
        if cmd['expires'] < now or occ not in self.scheduler.current(now):
            return 'expired'
        if any(e['kind']=='command_received' and e['detail']==cmd['id'] for e in self.journal.events):
            return 'duplicate'
        if cmd['type']=='snooze':
            self.journal.append('command_received',occ,now,cmd['id'])
            self.scheduler.snooze(occ,now,self.journal)
            return 'snoozed'
        if self.busy or self.journal.claimed(occ):
            return 'duplicate'
        self.busy=True
        self.state='validating'
        self.last_error=None
        claimed=False
        try:
            # Consume even blocked commands once; network retries cannot fill
            # the journal or turn an old blocked request into a later dispense.
            self.journal.append('command_received',occ,now,cmd['id'])
            before=await self.sensors.snapshot()
            reason=preflight(self.cfg,before,self.clock.trusted(),self.journal)
            slot=occ.split(':')[-1]
            expected=self.cfg.EXPECTED_DELTA_G.get(slot)
            if not finite(expected) or expected<=0 or not finite(self.cfg.DELTA_TOLERANCE_G) or not 0<=self.cfg.DELTA_TOLERANCE_G<expected:
                reason=reason or 'Delta calibration missing'
            try:
                self.servo.validate(slot)
            except Exception:
                reason=reason or 'Servo sequence unverified'
            now=self.clock.now()  # Sensor sampling may have consumed the window.
            if cmd['expires']<now or occ not in self.scheduler.current(now):
                reason=reason or 'Command expired during validation'
            # Reserve room for both durable attempt and final outcome.
            if self.journal.seq>126:
                reason=reason or 'Journal capacity insufficient for attempt'
            if reason:
                self.state='fault'; self.last_error=reason
                self.journal.append('blocked',occ,now,reason)
                return 'blocked'
            self.journal.append('attempt',occ,now,cmd['id'])
            claimed=True
            self.state='dispensing'
            await self.servo.release(slot,self.sensors.guard)
            self.state='verifying'
            remaining=getattr(self.cfg,'WEIGHT_SETTLE_MS',0)
            while remaining:
                step=min(20,remaining)
                await asyncio.sleep_ms(step)
                remaining-=step
                if not await self.sensors.guard():
                    raise RuntimeError('Interlock changed during settling')
            after=await self.sensors.snapshot()
            good=(interlocks(self.cfg,after) is None and weight_valid(self.cfg,after)
                  and verify_delta(before['weight_g'],after['weight_g'],expected,self.cfg.DELTA_TOLERANCE_G))
            kind='sensor_confirmed' if good else 'uncertain'
            self.journal.append(kind,occ,self.clock.now(),'Measured mass change only; ingestion unknown')
            self.state='completed' if good else 'fault'
            if not good:
                self.last_error='Mass verification inconclusive'
            return kind
        except BaseException as e:
            self.state='fault'
            self.last_error='Dispensing interrupted'
            if claimed and not self.journal.fault:
                self.journal.append('uncertain',occ,self.clock.now(),'Actuation or verification interrupted')
            if isinstance(e,Exception) and claimed:
                return 'uncertain'
            raise
        finally:
            self.busy=False
            self.servo.stop()
