import math
import time

def finite(v):
    return isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)

def interlocks(cfg, s):
    if s.get('faults'):
        return 'Sensor fault: ' + ','.join(s['faults'])
    if getattr(cfg,'CUP_SENSOR_REQUIRED',True) and s.get('cup_present') is not True:
        return 'Cup missing or unverified'
    if getattr(cfg,'LID_INTERLOCK_REQUIRED',True) and s.get('lid_closed') is not True:
        return 'Lid open or interlock unassigned'
    if s.get('docked') is True:
        return 'Undock portable unit before dispensing'
    if getattr(cfg,'DOCK_SENSOR_REQUIRED',False) and s.get('docked') is not False:
        return 'Dock attachment state unverified'
    if getattr(cfg,'MOTION_SENSOR_REQUIRED',True):
        if not finite(s.get('tilt_deg')) or not finite(s.get('motion_g')):
            return 'Motion sensor unavailable'
        if s['tilt_deg'] > cfg.MAX_TILT_DEG or s['motion_g'] > cfg.MAX_MOTION_G:
            return 'Movement/tilt unsafe'
    return None

def weight_valid(cfg, s):
    if not finite(s.get('weight_g')) or not s.get('stable'):
        return False
    if hasattr(cfg,'SENSOR_MAX_AGE_MS'):
        at = s.get('weight_at_ms')
        if at is None or not 0 <= time.ticks_diff(time.ticks_ms(),at) <= cfg.SENSOR_MAX_AGE_MS:
            return False
    return True

def preflight(cfg, s, clock_ok, journal):
    if journal.fault:
        return journal.fault
    confirmed = {e['occurrence'] for e in journal.events if e['kind'] in ('sensor_confirmed','reconciled')}
    if any(e['kind'] == 'attempt' and e['occurrence'] not in confirmed for e in journal.events):
        return 'Previous attempt unresolved; manual reconciliation required'
    if not clock_ok:
        return 'Clock untrusted'
    if not cfg.WIRING_VERIFIED:
        return 'Wiring unverified'
    if not cfg.ACTUATION_VERIFIED:
        return 'Release mechanism unverified'
    if not cfg.CALIBRATED:
        return 'Calibration incomplete'
    reason = interlocks(cfg,s)
    if reason:
        return reason
    if not weight_valid(cfg,s):
        return 'Invalid, stale or unstable weight'
    if not finite(cfg.EMPTY_CUP_G) or not finite(cfg.EMPTY_CUP_TOLERANCE_G) or cfg.EMPTY_CUP_TOLERANCE_G < 0:
        return 'Cup calibration missing'
    if abs(s['weight_g'] - cfg.EMPTY_CUP_G) > cfg.EMPTY_CUP_TOLERANCE_G:
        return 'Cup is not empty or wrong cup'
    return None

def verify_delta(before, after, expected, tolerance):
    return (all(finite(v) for v in (before,after,expected,tolerance)) and expected > 0 and
            0 <= tolerance < expected and after > before and abs(after-before-expected) <= tolerance)
