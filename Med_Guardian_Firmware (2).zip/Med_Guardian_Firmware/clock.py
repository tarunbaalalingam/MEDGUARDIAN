import time
class Clock:
    def __init__(self,max_age=86400): self.base=None; self.tick=None; self.max_age=max_age; self.invalid=False
    def sync(self,epoch):
        if type(epoch)!=int or epoch<1700000000: raise ValueError('Invalid server time')
        if self.base is not None and abs(epoch-self.now())>60:
            self.invalid=True; raise ValueError('Clock jump: restart and reconcile')
        self.base=epoch; self.tick=time.ticks_ms()
    def now(self):
        return 0 if self.base is None else self.base+time.ticks_diff(time.ticks_ms(),self.tick)//1000
    def trusted(self): return self.base is not None and not self.invalid and 0<=self.now()-self.base<=self.max_age
